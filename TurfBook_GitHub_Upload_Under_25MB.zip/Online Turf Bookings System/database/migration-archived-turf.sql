-- Online Turf Booking System - Migration
-- Add ARCHIVED status to turfs table to support soft delete / preserving booking history
-- Safe to run on existing MySQL databases with live data

USE online_turf_booking;

ALTER TABLE turfs
    MODIFY COLUMN status ENUM('ACTIVE', 'INACTIVE', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE';
