-- Online Turf Booking System - Database Schema
-- MySQL 8+
-- Database: online_turf_booking

CREATE DATABASE IF NOT EXISTS online_turf_booking
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE online_turf_booking;

-- -----------------------------------------------------
-- users
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name     VARCHAR(120)    NOT NULL,
    email         VARCHAR(180)    NOT NULL,
    password_hash VARCHAR(100)    NOT NULL,
    phone         VARCHAR(20)     NOT NULL,
    role          ENUM('CUSTOMER', 'ADMIN') NOT NULL DEFAULT 'CUSTOMER',
    status        ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_users_email (email),
    KEY idx_users_role (role),
    KEY idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------
-- turfs
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS turfs (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name            VARCHAR(150)    NOT NULL,
    location        VARCHAR(255)    NOT NULL,
    description     TEXT            NOT NULL,
    price_per_hour  DECIMAL(10,2)   NOT NULL,
    opening_time    TIME            NOT NULL,
    closing_time    TIME            NOT NULL,
    amenities       VARCHAR(500)    NOT NULL,
    image_path      VARCHAR(255)    DEFAULT NULL,
    image_color     VARCHAR(20)     DEFAULT '#1a5c3a',
    status          ENUM('ACTIVE', 'INACTIVE', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_turfs_status (status),
    KEY idx_turfs_location (location),
    CONSTRAINT chk_turfs_price CHECK (price_per_hour > 0),
    CONSTRAINT chk_turfs_hours CHECK (closing_time > opening_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------
-- bookings
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS bookings (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    booking_code  VARCHAR(20)     NOT NULL,
    customer_id   BIGINT UNSIGNED NOT NULL,
    turf_id       BIGINT UNSIGNED NOT NULL,
    booking_date  DATE            NOT NULL,
    start_time    TIME            NOT NULL,
    end_time      TIME            NOT NULL,
    duration_hours DECIMAL(4,1)   NOT NULL,
    price_per_hour DECIMAL(10,2)  NOT NULL,
    total_amount  DECIMAL(10,2)   NOT NULL,
    status        ENUM('CONFIRMED', 'CANCELLED', 'COMPLETED') NOT NULL DEFAULT 'CONFIRMED',
    notes         VARCHAR(500)    DEFAULT NULL,
    created_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_bookings_code (booking_code),
    KEY idx_bookings_customer (customer_id),
    KEY idx_bookings_turf (turf_id),
    KEY idx_bookings_date (booking_date),
    KEY idx_bookings_status (status),
    CONSTRAINT fk_bookings_customer FOREIGN KEY (customer_id) REFERENCES users(id),
    CONSTRAINT fk_bookings_turf FOREIGN KEY (turf_id) REFERENCES turfs(id),
    CONSTRAINT chk_bookings_time CHECK (end_time > start_time),
    CONSTRAINT chk_bookings_duration CHECK (duration_hours > 0),
    CONSTRAINT chk_bookings_amount CHECK (total_amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------
-- booking_slots
-- Each row represents one occupied hour slot for a turf on a date.
-- Booking 09:00-11:00 creates rows for 09:00 and 10:00.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS booking_slots (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    booking_id  BIGINT UNSIGNED NOT NULL,
    turf_id     BIGINT UNSIGNED NOT NULL,
    slot_date   DATE            NOT NULL,
    slot_hour   TINYINT UNSIGNED NOT NULL COMMENT 'Hour of day 0-23 representing slot start',
    created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_slot_unique (turf_id, slot_date, slot_hour),
    KEY idx_slots_booking (booking_id),
    KEY idx_slots_lookup (turf_id, slot_date),
    CONSTRAINT fk_slots_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    CONSTRAINT fk_slots_turf FOREIGN KEY (turf_id) REFERENCES turfs(id),
    CONSTRAINT chk_slot_hour CHECK (slot_hour >= 0 AND slot_hour <= 23)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
