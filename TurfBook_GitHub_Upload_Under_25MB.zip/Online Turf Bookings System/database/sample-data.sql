-- Online Turf Booking System - Sample Data
-- Run AFTER schema.sql
--
-- Demo credentials (BCrypt hashed below):
--   Admin:    admin@turfbook.com / Admin@123
--   Customer: rahul@example.com  / Customer@123
--             priya@example.com  / Customer@123
--             arjun@example.com  / Customer@123

USE online_turf_booking;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE booking_slots;
TRUNCATE TABLE bookings;
TRUNCATE TABLE turfs;
TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

-- Password hashes generated with jBCrypt
INSERT INTO users (full_name, email, password_hash, phone, role, status) VALUES
('System Admin', 'admin@turfbook.com', '$2a$10$VmDhJ3cymGt/bUs4rIHjj.NhwPd4VeSo9VRZV/qaN.yecrFAYWFR2', '9876543210', 'ADMIN', 'ACTIVE'),
('Rahul Sharma', 'rahul@example.com', '$2a$10$KwlsnTVWvT3EtYv7.uUJFOPxIlGxWXFeFROC5tu9iWeRiByGIN9He', '9876501234', 'CUSTOMER', 'ACTIVE'),
('Priya Nair', 'priya@example.com', '$2a$10$KwlsnTVWvT3EtYv7.uUJFOPxIlGxWXFeFROC5tu9iWeRiByGIN9He', '9876505678', 'CUSTOMER', 'ACTIVE'),
('Arjun Kumar', 'arjun@example.com', '$2a$10$KwlsnTVWvT3EtYv7.uUJFOPxIlGxWXFeFROC5tu9iWeRiByGIN9He', '9876509012', 'CUSTOMER', 'ACTIVE');

INSERT INTO turfs (name, location, description, price_per_hour, opening_time, closing_time, amenities, image_path, image_color, status) VALUES
('Green Arena', 'Anna Nagar, Chennai',
 'A well-maintained 5-a-side turf with consistent bounce and evening floodlights. Ideal for weekday practice and weekend friendlies.',
 900.00, '06:00:00', '22:00:00', 'Floodlights, Changing rooms, Parking, Drinking water', 'images/turfs/turf1.jpg', '#1a5c3a', 'ACTIVE'),
('Urban Turf', 'T. Nagar, Chennai',
 'Compact city turf designed for quick pick-up games. Synthetic surface with strong grip and nearby metro access.',
 1100.00, '07:00:00', '23:00:00', 'Floodlights, Lockers, Cafe, First aid', 'images/turfs/turf2.jpg', '#245c4a', 'ACTIVE'),
('Elite Sports Ground', 'OMR, Sholinganallur',
 'Premium full-size football turf with coaching-ready markings and spectator seating for competitive matches.',
 1500.00, '06:00:00', '22:00:00', 'Floodlights, Seating, Changing rooms, Parking, Washrooms', 'images/turfs/turf3.jpg', '#163d2c', 'ACTIVE'),
('City Football Turf', 'Velachery, Chennai',
 'Community-favorite turf with reliable booking slots and a smooth synthetic pitch for youth and corporate teams.',
 800.00, '06:00:00', '21:00:00', 'Parking, Drinking water, Washrooms', 'images/turfs/turf4.jpg', '#2f6b4f', 'ACTIVE'),
('Victory Arena', 'Porur, Chennai',
 'Spacious multi-sport turf with crisp lines and strong night visibility — popular for tournaments and training camps.',
 1200.00, '05:00:00', '23:00:00', 'Floodlights, Changing rooms, Parking, Equipment rental', 'images/turfs/turf5.jpg', '#1f4a37', 'ACTIVE');

-- Sample future bookings (safe for demos)
INSERT INTO bookings (booking_code, customer_id, turf_id, booking_date, start_time, end_time, duration_hours, price_per_hour, total_amount, status)
VALUES
('TBDEMO0001', 2, 1, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '18:00:00', '20:00:00', 2.0, 900.00, 1800.00, 'CONFIRMED'),
('TBDEMO0002', 3, 2, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '09:00:00', '10:00:00', 1.0, 1100.00, 1100.00, 'CONFIRMED'),
('TBDEMO0003', 4, 3, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '16:00:00', '18:00:00', 2.0, 1500.00, 3000.00, 'COMPLETED');

INSERT INTO booking_slots (booking_id, turf_id, slot_date, slot_hour)
SELECT b.id, b.turf_id, b.booking_date, 18 FROM bookings b WHERE b.booking_code = 'TBDEMO0001'
UNION ALL
SELECT b.id, b.turf_id, b.booking_date, 19 FROM bookings b WHERE b.booking_code = 'TBDEMO0001'
UNION ALL
SELECT b.id, b.turf_id, b.booking_date, 9 FROM bookings b WHERE b.booking_code = 'TBDEMO0002';
-- COMPLETED demo booking intentionally has no active slots (already finished / released)
