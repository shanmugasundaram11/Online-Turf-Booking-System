@echo off
REM Setup MySQL database for Online Turf Booking System
REM Usage: setup-database.bat YOUR_MYSQL_PASSWORD

if "%~1"=="" (
  echo Usage: setup-database.bat YOUR_MYSQL_ROOT_PASSWORD
  exit /b 1
)

set MYSQL="C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
if not exist %MYSQL% set MYSQL=mysql

echo Creating schema...
%MYSQL% -u root -p%~1 < database\schema.sql
if errorlevel 1 exit /b 1

echo Loading sample data...
%MYSQL% -u root -p%~1 < database\sample-data.sql
if errorlevel 1 exit /b 1

echo Done. Update src\main\resources\db.properties with the same password, then rebuild.
