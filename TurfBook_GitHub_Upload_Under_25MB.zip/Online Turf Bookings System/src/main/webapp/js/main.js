(function () {
    "use strict";

    function qs(sel, root) {
        return (root || document).querySelector(sel);
    }

    function qsa(sel, root) {
        return Array.from((root || document).querySelectorAll(sel));
    }

    function initNav() {
        var toggle = qs("[data-nav-toggle]");
        var nav = qs("[data-nav]");
        if (!toggle || !nav) return;
        toggle.addEventListener("click", function () {
            var open = nav.classList.toggle("open");
            toggle.setAttribute("aria-expanded", open ? "true" : "false");
        });
    }

    function initAdminNav() {
        var toggle = qs("[data-admin-toggle]");
        var sidebar = qs("[data-admin-sidebar]");
        if (!toggle || !sidebar) return;
        toggle.addEventListener("click", function () {
            sidebar.classList.toggle("open");
        });
    }

    function initToasts() {
        qsa("[data-toast]").forEach(function (toast) {
            setTimeout(function () {
                toast.style.opacity = "0";
                toast.style.transform = "translateY(-8px)";
                setTimeout(function () {
                    toast.remove();
                }, 250);
            }, 4200);
        });
    }

    function initPasswordToggle() {
        qsa("[data-password-toggle]").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var input = qs(btn.getAttribute("data-password-toggle"));
                if (!input) return;
                var show = input.type === "password";
                input.type = show ? "text" : "password";
                btn.textContent = show ? "Hide" : "Show";
            });
        });
    }

    function initConfirmDialogs() {
        qsa("[data-confirm]").forEach(function (el) {
            el.addEventListener("click", function (e) {
                var message = el.getAttribute("data-confirm") || "Are you sure?";
                if (!window.confirm(message)) {
                    e.preventDefault();
                }
            });
        });
    }

    function initBookingSlots() {
        var root = qs("[data-booking-root]");
        if (!root) return;

        var turfId = root.getAttribute("data-turf-id");
        var price = parseFloat(root.getAttribute("data-price") || "0");
        var dateInput = qs("#bookingDate", root);
        var slotGrid = qs("[data-slot-grid]", root);
        var hoursInput = qs("#selectedHours", root);
        var summaryHours = qs("[data-summary-hours]", root);
        var summaryRange = qs("[data-summary-range]", root);
        var summaryTotal = qs("[data-summary-total]", root);
        var submitBtn = qs("[data-booking-submit]", root);
        var loading = qs("[data-slots-loading]", root);
        var csrf = qs("input[name='_csrf']", root);
        var ctx = root.getAttribute("data-ctx") || "";

        var selected = [];

        function formatMoney(n) {
            return "₹" + n.toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
        }

        function updateSummary() {
            selected.sort(function (a, b) {
                return a - b;
            });
            if (hoursInput) {
                hoursInput.value = selected.join(",");
            }
            if (!selected.length) {
                if (summaryHours) summaryHours.textContent = "—";
                if (summaryRange) summaryRange.textContent = "—";
                if (summaryTotal) summaryTotal.textContent = formatMoney(0);
                if (submitBtn) submitBtn.disabled = true;
                return;
            }
            var start = selected[0];
            var end = selected[selected.length - 1] + 1;
            if (summaryHours) summaryHours.textContent = selected.length + (selected.length === 1 ? " hour" : " hours");
            if (summaryRange) {
                summaryRange.textContent =
                    String(start).padStart(2, "0") + ":00 – " + String(end).padStart(2, "0") + ":00";
            }
            if (summaryTotal) summaryTotal.textContent = formatMoney(price * selected.length);
            if (submitBtn) submitBtn.disabled = false;
        }

        function isConsecutive(hours) {
            if (!hours.length) return true;
            var sorted = hours.slice().sort(function (a, b) {
                return a - b;
            });
            for (var i = 1; i < sorted.length; i++) {
                if (sorted[i] !== sorted[i - 1] + 1) return false;
            }
            return true;
        }

        function renderSlots(slots) {
            if (!slotGrid) return;
            slotGrid.innerHTML = "";
            selected = [];
            updateSummary();

            if (!slots.length) {
                slotGrid.innerHTML = '<p class="muted">No slots available for this date.</p>';
                return;
            }

            slots.forEach(function (slot) {
                var btn = document.createElement("button");
                btn.type = "button";
                btn.className = "slot-btn " + (slot.available ? "available" : "unavailable");
                btn.textContent = slot.label;
                btn.dataset.hour = String(slot.hour);
                btn.disabled = !slot.available;
                if (slot.available) {
                    btn.addEventListener("click", function () {
                        var hour = parseInt(btn.dataset.hour, 10);
                        var idx = selected.indexOf(hour);
                        if (idx >= 0) {
                            selected.splice(idx, 1);
                            btn.classList.remove("selected");
                        } else {
                            var next = selected.concat([hour]);
                            if (!isConsecutive(next)) {
                                showInlineError("Please select consecutive hourly slots only.");
                                return;
                            }
                            selected.push(hour);
                            btn.classList.add("selected");
                        }
                        clearInlineError();
                        updateSummary();
                    });
                }
                slotGrid.appendChild(btn);
            });
        }

        function showInlineError(msg) {
            var el = qs("[data-slot-error]", root);
            if (!el) return;
            el.textContent = msg;
            el.hidden = false;
        }

        function clearInlineError() {
            var el = qs("[data-slot-error]", root);
            if (!el) return;
            el.textContent = "";
            el.hidden = true;
        }

        function loadSlots() {
            if (!dateInput || !dateInput.value) return;
            if (loading) loading.hidden = false;
            if (slotGrid) slotGrid.classList.add("loading-overlay");

            fetch(ctx + "/api/availability?turfId=" + encodeURIComponent(turfId) + "&date=" + encodeURIComponent(dateInput.value))
                .then(function (res) {
                    return res.json().then(function (data) {
                        if (!res.ok) throw new Error(data.error || "Unable to load availability");
                        return data;
                    });
                })
                .then(function (data) {
                    renderSlots(data.slots || []);
                })
                .catch(function (err) {
                    if (slotGrid) {
                        slotGrid.innerHTML = '<p class="alert alert-error">' + (err.message || "Failed to load slots") + "</p>";
                    }
                })
                .finally(function () {
                    if (loading) loading.hidden = true;
                    if (slotGrid) slotGrid.classList.remove("loading-overlay");
                });
        }

        if (dateInput) {
            dateInput.addEventListener("change", loadSlots);
        }

        var form = qs("#bookingForm", root);
        if (form) {
            form.addEventListener("submit", function (e) {
                if (!selected.length) {
                    e.preventDefault();
                    showInlineError("Select at least one available time slot.");
                    return;
                }
                if (!isConsecutive(selected)) {
                    e.preventDefault();
                    showInlineError("Selected slots must be consecutive.");
                    return;
                }
                if (!window.confirm("Confirm booking for the selected slots?")) {
                    e.preventDefault();
                }
            });
        }

        // Ensure CSRF present for fetch-less form posts
        if (csrf && !csrf.value) {
            // token set server-side
        }

        loadSlots();
    }

    function initClientValidation() {
        qsa("form[data-validate]").forEach(function (form) {
            form.addEventListener("submit", function (e) {
                var password = qs("[name='password']", form);
                var confirm = qs("[name='confirmPassword']", form);
                if (password && confirm && password.value !== confirm.value) {
                    e.preventDefault();
                    alert("Password and confirm password do not match.");
                }
            });
        });
    }

    function initLogoutModal() {
        var modal = qs("#logoutModal");
        var triggers = qsa("[data-logout-open]");
        if (!modal || !triggers.length) return;

        var cancelBtn = qs("[data-logout-cancel]", modal);
        var previouslyFocused = null;

        function getFocusableElements() {
            var focusables = modal.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
            return Array.from(focusables).filter(function (el) {
                return el.offsetWidth > 0 || el.offsetHeight > 0 || el === document.activeElement;
            });
        }

        function openModal(e) {
            if (e) {
                e.preventDefault();
            }
            previouslyFocused = document.activeElement;
            modal.removeAttribute("hidden");
            modal.classList.add("open");
            if (cancelBtn) {
                cancelBtn.focus();
            }
            document.addEventListener("keydown", handleKeyDown);
        }

        function closeModal() {
            modal.classList.remove("open");
            modal.setAttribute("hidden", "");
            document.removeEventListener("keydown", handleKeyDown);
            if (previouslyFocused && typeof previouslyFocused.focus === "function") {
                previouslyFocused.focus();
            }
        }

        function handleKeyDown(e) {
            if (e.key === "Escape" || e.keyCode === 27) {
                e.preventDefault();
                closeModal();
                return;
            }

            if (e.key === "Tab" || e.keyCode === 9) {
                var focusables = getFocusableElements();
                if (!focusables.length) return;
                var first = focusables[0];
                var last = focusables[focusables.length - 1];

                if (e.shiftKey) {
                    if (document.activeElement === first) {
                        e.preventDefault();
                        last.focus();
                    }
                } else {
                    if (document.activeElement === last) {
                        e.preventDefault();
                        first.focus();
                    }
                }
            }
        }

        triggers.forEach(function (trigger) {
            trigger.addEventListener("click", openModal);
        });

        if (cancelBtn) {
            cancelBtn.addEventListener("click", function (e) {
                e.preventDefault();
                closeModal();
            });
        }

        modal.addEventListener("click", function (e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    }

    function initDeleteTurfModal() {
        var modal = qs("#deleteTurfModal");
        var triggers = qsa("[data-delete-turf]");
        if (!modal || !triggers.length) return;

        var nameEl = qs("#deleteTurfName", modal);
        var idInput = qs("#deleteTurfId", modal);
        var form = qs("#deleteTurfForm", modal);
        var cancelBtn = qs("[data-delete-cancel]", modal);
        var confirmBtn = qs("#deleteConfirmBtn", modal);
        var previouslyFocused = null;
        var submitting = false;

        function getFocusableElements() {
            var focusables = modal.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
            return Array.from(focusables).filter(function (el) {
                return el.offsetWidth > 0 || el.offsetHeight > 0 || el === document.activeElement;
            });
        }

        function openModal(e) {
            if (e) {
                e.preventDefault();
            }
            var trigger = e.currentTarget || e.target;
            var turfId = trigger.getAttribute("data-turf-id");
            var turfName = trigger.getAttribute("data-turf-name");

            if (idInput) {
                idInput.value = turfId || "";
            }
            if (nameEl) {
                nameEl.textContent = turfName || "this turf";
            }

            submitting = false;
            if (confirmBtn) {
                confirmBtn.disabled = false;
                confirmBtn.textContent = "Delete Turf";
            }

            previouslyFocused = document.activeElement;
            modal.removeAttribute("hidden");
            modal.classList.add("open");
            if (cancelBtn) {
                cancelBtn.focus();
            }
            document.addEventListener("keydown", handleKeyDown);
        }

        function closeModal() {
            modal.classList.remove("open");
            modal.setAttribute("hidden", "");
            document.removeEventListener("keydown", handleKeyDown);
            if (previouslyFocused && typeof previouslyFocused.focus === "function") {
                previouslyFocused.focus();
            }
        }

        function handleKeyDown(e) {
            if (e.key === "Escape" || e.keyCode === 27) {
                e.preventDefault();
                closeModal();
                return;
            }

            if (e.key === "Tab" || e.keyCode === 9) {
                var focusables = getFocusableElements();
                if (!focusables.length) return;
                var first = focusables[0];
                var last = focusables[focusables.length - 1];

                if (e.shiftKey) {
                    if (document.activeElement === first) {
                        e.preventDefault();
                        last.focus();
                    }
                } else {
                    if (document.activeElement === last) {
                        e.preventDefault();
                        first.focus();
                    }
                }
            }
        }

        triggers.forEach(function (trigger) {
            trigger.addEventListener("click", openModal);
        });

        if (cancelBtn) {
            cancelBtn.addEventListener("click", function (e) {
                e.preventDefault();
                closeModal();
            });
        }

        modal.addEventListener("click", function (e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        if (form) {
            form.addEventListener("submit", function (e) {
                if (submitting) {
                    e.preventDefault();
                    return;
                }
                submitting = true;
                if (confirmBtn) {
                    confirmBtn.disabled = true;
                    confirmBtn.textContent = "Deleting...";
                }
            });
        }
    }

    document.addEventListener("DOMContentLoaded", function () {
        initNav();
        initAdminNav();
        initToasts();
        initPasswordToggle();
        initConfirmDialogs();
        initBookingSlots();
        initClientValidation();
        initLogoutModal();
        initDeleteTurfModal();
    });
})();

