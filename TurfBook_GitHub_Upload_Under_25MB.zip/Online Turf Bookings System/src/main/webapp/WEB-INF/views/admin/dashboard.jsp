<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Admin Dashboard" scope="request"/>
<c:set var="pageHeading" value="Dashboard" scope="request"/>
<c:set var="activeNav" value="dashboard" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="admin-stats">
    <article class="stat-card"><p class="label">Total turfs</p><p class="value">${stats.totalTurfs}</p></article>
    <article class="stat-card"><p class="label">Total bookings</p><p class="value">${stats.totalBookings}</p></article>
    <article class="stat-card"><p class="label">Customers</p><p class="value">${stats.totalCustomers}</p></article>
    <article class="stat-card"><p class="label">Confirmed</p><p class="value">${stats.confirmedBookings}</p></article>
    <article class="stat-card"><p class="label">Cancelled</p><p class="value">${stats.cancelledBookings}</p></article>
    <article class="stat-card"><p class="label">Active turfs</p><p class="value">${stats.activeTurfs}</p></article>
</div>

<div class="dashboard-grid">
    <div class="panel">
        <h2>Recent bookings</h2>
        <div class="table-wrap" style="box-shadow:none;border:0;">
            <table>
                <thead>
                <tr><th>Code</th><th>Customer</th><th>Turf</th><th>Date</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                <c:forEach var="b" items="${recentBookings}">
                    <tr>
                        <td>${b.bookingCode}</td>
                        <td><c:out value="${b.customerName}"/></td>
                        <td><c:out value="${b.turfName}"/></td>
                        <td>${b.bookingDateFormatted}</td>
                        <td>${b.status}</td>
                        <td><a href="${ctx}/admin/bookings/${b.id}">View</a></td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
            <c:if test="${empty recentBookings}"><p class="muted">No bookings yet.</p></c:if>
        </div>
    </div>
    <div class="panel">
        <h2>Turf availability</h2>
        <c:forEach var="t" items="${turfs}">
            <div class="summary-row">
                <span><c:out value="${t.name}"/></span>
                <span class="badge badge-success">ACTIVE</span>
            </div>
        </c:forEach>
        <c:if test="${empty turfs}"><p class="muted">No active turfs.</p></c:if>
        <a class="btn btn-secondary btn-sm" style="margin-top:1rem;" href="${ctx}/admin/turfs">Manage turfs</a>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
