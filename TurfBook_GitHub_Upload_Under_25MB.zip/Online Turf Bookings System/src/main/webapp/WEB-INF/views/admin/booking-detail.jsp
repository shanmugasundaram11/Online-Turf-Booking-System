<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Booking Detail" scope="request"/>
<c:set var="pageHeading" value="Booking detail" scope="request"/>
<c:set var="activeNav" value="bookings" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="detail-layout">
    <div class="panel">
        <h2>${booking.bookingCode}</h2>
        <div class="summary-row"><span>Customer</span><span><c:out value="${booking.customerName}"/></span></div>
        <div class="summary-row"><span>Email</span><span><c:out value="${booking.customerEmail}"/></span></div>
        <div class="summary-row"><span>Phone</span><span><c:out value="${booking.customerPhone}"/></span></div>
        <div class="summary-row"><span>Turf</span><span><c:out value="${booking.turfName}"/></span></div>
        <div class="summary-row"><span>Date</span><span>${booking.bookingDateFormatted}</span></div>
        <div class="summary-row"><span>Time</span><span>${booking.startTimeFormatted} – ${booking.endTimeFormatted}</span></div>
        <div class="summary-row"><span>Duration</span><span>${booking.durationHours} hr</span></div>
        <div class="summary-row"><span>Total</span><span>₹<fmt:formatNumber value="${booking.totalAmount}" maxFractionDigits="0"/></span></div>
        <div class="summary-row"><span>Status</span><span>${booking.status}</span></div>
    </div>
    <div class="panel">
        <h3>Update status</h3>
        <%-- Only CONFIRMED bookings can transition to another status --%>
        <c:choose>
            <c:when test="${booking.status == 'CONFIRMED'}">
                <form method="post" action="${ctx}/admin/bookings">
                    <input type="hidden" name="_csrf" value="${csrfToken}">
                    <input type="hidden" name="id" value="${booking.id}">
                    <div class="form-group">
                        <label for="status">New status</label>
                        <select id="status" name="status">
                            <option value="CANCELLED">CANCELLED &ndash; release slots</option>
                            <option value="COMPLETED">COMPLETED &ndash; mark session done (only after end time)</option>
                        </select>
                    </div>
                    <button class="btn btn-primary" type="submit" data-confirm="Update booking status?">Save status</button>
                </form>
                <p class="form-hint">Cancelling or completing a booking removes its occupied hour slots so they become bookable again.</p>
            </c:when>
            <c:when test="${booking.status == 'CANCELLED'}">
                <p class="muted">This booking is <strong>CANCELLED</strong>. Cancelled bookings are final and cannot be changed.</p>
            </c:when>
            <c:when test="${booking.status == 'COMPLETED'}">
                <p class="muted">This booking is <strong>COMPLETED</strong>. Completed bookings are final and cannot be changed.</p>
            </c:when>
        </c:choose>
        <a class="btn btn-secondary" href="${ctx}/admin/bookings">Back to list</a>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
