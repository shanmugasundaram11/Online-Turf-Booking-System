<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Turf Management" scope="request"/>
<c:set var="pageHeading" value="Turf Management" scope="request"/>
<c:set var="activeNav" value="turfs" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="toolbar">
    <form class="filters" method="get" action="${ctx}/admin/turfs" style="flex:1;">
        <div class="form-group">
            <input type="search" name="q" value="${searchQuery}" placeholder="Search turfs...">
        </div>
        <div class="form-group">
            <select name="status">
                <option value="ALL" ${statusFilter == 'ALL' || empty statusFilter ? 'selected' : ''}>All statuses</option>
                <option value="ACTIVE" ${statusFilter == 'ACTIVE' ? 'selected' : ''}>Active</option>
                <option value="INACTIVE" ${statusFilter == 'INACTIVE' ? 'selected' : ''}>Inactive</option>
                <option value="ARCHIVED" ${statusFilter == 'ARCHIVED' ? 'selected' : ''}>Archived</option>
            </select>
        </div>
        <button class="btn btn-secondary" type="submit">Filter</button>
    </form>
    <a class="btn btn-primary" href="${ctx}/admin/turfs/new">Add turf</a>
</div>

<div class="table-wrap">
    <table>
        <thead>
        <tr>
            <th>Name</th>
            <th>Location</th>
            <th>Price/hr</th>
            <th>Hours</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="t" items="${turfs}">
            <tr>
                <td><c:out value="${t.name}"/></td>
                <td><c:out value="${t.location}"/></td>
                <td>₹<fmt:formatNumber value="${t.pricePerHour}" maxFractionDigits="0"/></td>
                <td>${t.openingTimeFormatted}–${t.closingTimeFormatted}</td>
                <td>
                    <c:choose>
                        <c:when test="${t.status == 'ACTIVE'}"><span class="badge badge-success">ACTIVE</span></c:when>
                        <c:when test="${t.status == 'ARCHIVED'}"><span class="badge badge-warning">ARCHIVED</span></c:when>
                        <c:otherwise><span class="badge badge-neutral">INACTIVE</span></c:otherwise>
                    </c:choose>
                </td>
                <td>
                    <a href="${ctx}/admin/turfs/${t.id}">View</a> ·
                    <c:choose>
                        <c:when test="${t.status == 'ARCHIVED'}">
                            <form class="inline-form" method="post" action="${ctx}/admin/turfs">
                                <input type="hidden" name="_csrf" value="${csrfToken}">
                                <input type="hidden" name="action" value="restore">
                                <input type="hidden" name="id" value="${t.id}">
                                <button class="btn btn-ghost btn-sm" type="submit"
                                        data-confirm="Restore archived turf '<c:out value="${t.name}"/>' to Inactive status?">
                                    Restore
                                </button>
                            </form> ·
                            <button type="button" class="btn btn-ghost btn-sm btn-delete-turf"
                                    data-delete-turf
                                    data-turf-id="${t.id}"
                                    data-turf-name="<c:out value="${t.name}"/>"
                                    aria-haspopup="dialog">
                                Delete
                            </button>
                        </c:when>
                        <c:otherwise>
                            <a href="${ctx}/admin/turfs/${t.id}/edit">Edit</a> ·
                            <form class="inline-form" method="post" action="${ctx}/admin/turfs">
                                <input type="hidden" name="_csrf" value="${csrfToken}">
                                <input type="hidden" name="action" value="toggle">
                                <input type="hidden" name="id" value="${t.id}">
                                <input type="hidden" name="status" value="${t.status == 'ACTIVE' ? 'INACTIVE' : 'ACTIVE'}">
                                <button class="btn btn-ghost btn-sm" type="submit"
                                        data-confirm="Change status of ${t.name}?">
                                    ${t.status == 'ACTIVE' ? 'Deactivate' : 'Activate'}
                                </button>
                            </form> ·
                            <button type="button" class="btn btn-ghost btn-sm btn-delete-turf"
                                    data-delete-turf
                                    data-turf-id="${t.id}"
                                    data-turf-name="<c:out value="${t.name}"/>"
                                    aria-haspopup="dialog">
                                Delete
                            </button>
                        </c:otherwise>
                    </c:choose>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
<c:if test="${empty turfs}">
    <div class="empty-state"><p>No turfs found.</p></div>
</c:if>

<div id="deleteTurfModal"
     class="dialog-backdrop"
     role="dialog"
     aria-modal="true"
     aria-labelledby="deleteModalTitle"
     aria-describedby="deleteModalDesc"
     hidden>
    <div class="dialog" tabindex="-1">
        <h2 id="deleteModalTitle" class="dialog-title">Delete Turf</h2>
        <p id="deleteModalDesc" class="dialog-message">
            Are you sure you want to delete <strong id="deleteTurfName"></strong>? If this turf has past booking records, it will be safely archived to preserve booking history; if it has no bookings, it will be permanently deleted.
        </p>
        <div class="dialog-actions">
            <button type="button" class="btn btn-secondary" data-delete-cancel>Cancel</button>
            <form id="deleteTurfForm" method="post" action="${ctx}/admin/turfs" class="inline-form">
                <input type="hidden" name="_csrf" value="${csrfToken}">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="deleteTurfId" value="">
                <button type="submit" class="btn btn-danger" id="deleteConfirmBtn">Delete Turf</button>
            </form>
        </div>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
