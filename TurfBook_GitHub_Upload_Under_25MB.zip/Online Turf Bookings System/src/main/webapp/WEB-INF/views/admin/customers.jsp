<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Customer Management" scope="request"/>
<c:set var="pageHeading" value="Customer Management" scope="request"/>
<c:set var="activeNav" value="customers" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<form class="filters" method="get" action="${ctx}/admin/customers">
    <div class="form-group">
        <input type="search" name="q" value="${searchQuery}" placeholder="Search name, email, phone...">
    </div>
    <button class="btn btn-secondary" type="submit">Search</button>
</form>

<div class="table-wrap">
    <table>
        <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Status</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="cuser" items="${customers}">
            <tr>
                <td><c:out value="${cuser.fullName}"/></td>
                <td><c:out value="${cuser.email}"/></td>
                <td><c:out value="${cuser.phone}"/></td>
                <td>
                    <c:choose>
                        <c:when test="${cuser.status == 'ACTIVE'}"><span class="badge badge-success">ACTIVE</span></c:when>
                        <c:otherwise><span class="badge badge-neutral">INACTIVE</span></c:otherwise>
                    </c:choose>
                </td>
                <td><a href="${ctx}/admin/customers/${cuser.id}">View</a></td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
<c:if test="${empty customers}">
    <div class="empty-state"><p>No customers found.</p></div>
</c:if>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
