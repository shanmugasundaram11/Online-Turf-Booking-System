<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="${turf.name}" scope="request"/>
<c:set var="pageHeading" value="Turf details" scope="request"/>
<c:set var="activeNav" value="turfs" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="panel">
    <c:choose>
        <c:when test="${not empty turf.imagePath}">
            <div class="turf-visual turf-visual-img" style="height:180px;border-radius:14px;margin-bottom:1rem;">
                <img src="${ctx}/${turf.imagePath}"
                     alt="${turf.name}"
                     class="turf-img"
                     onerror="this.parentElement.classList.remove('turf-visual-img');this.parentElement.style.background='linear-gradient(145deg,${turf.imageColor},#111411)';this.remove();">
            </div>
        </c:when>
        <c:otherwise>
            <div class="turf-visual" style="height:180px;border-radius:14px;margin-bottom:1rem;background:linear-gradient(145deg, ${turf.imageColor}, #111411);"></div>
        </c:otherwise>
    </c:choose>
    <h2><c:out value="${turf.name}"/></h2>
    <p class="muted"><c:out value="${turf.location}"/></p>
    <p><c:out value="${turf.description}"/></p>
    <div class="summary-row"><span>Price / hour</span><span>₹<fmt:formatNumber value="${turf.pricePerHour}" maxFractionDigits="0"/></span></div>
    <div class="summary-row"><span>Hours</span><span>${turf.openingTimeFormatted} – ${turf.closingTimeFormatted}</span></div>
    <div class="summary-row"><span>Status</span><span>${turf.status}</span></div>
    <h3>Amenities</h3>
    <ul class="amenity-list">
        <c:forEach var="a" items="${turf.amenityList}"><li><c:out value="${a}"/></li></c:forEach>
    </ul>
    <div style="margin-top:1.25rem;display:flex;gap:0.75rem;align-items:center;">
        <c:choose>
            <c:when test="${turf.status == 'ARCHIVED'}">
                <form class="inline-form" method="post" action="${ctx}/admin/turfs">
                    <input type="hidden" name="_csrf" value="${csrfToken}">
                    <input type="hidden" name="action" value="restore">
                    <input type="hidden" name="id" value="${turf.id}">
                    <button class="btn btn-primary" type="submit"
                            data-confirm="Restore archived turf '<c:out value="${turf.name}"/>' to Inactive status?">
                        Restore Turf
                    </button>
                </form>
            </c:when>
            <c:otherwise>
                <a class="btn btn-primary" href="${ctx}/admin/turfs/${turf.id}/edit">Edit</a>
            </c:otherwise>
        </c:choose>
        <a class="btn btn-secondary" href="${ctx}/admin/turfs">Back</a>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
