<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Customer Detail" scope="request"/>
<c:set var="pageHeading" value="Customer detail" scope="request"/>
<c:set var="activeNav" value="customers" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="detail-layout">
    <div class="panel">
        <h2><c:out value="${customer.fullName}"/></h2>
        <div class="summary-row"><span>Email</span><span><c:out value="${customer.email}"/></span></div>
        <div class="summary-row"><span>Phone</span><span><c:out value="${customer.phone}"/></span></div>
        <div class="summary-row"><span>Status</span><span>${customer.status}</span></div>
        <form method="post" action="${ctx}/admin/customers" style="margin-top:1.25rem;">
            <input type="hidden" name="_csrf" value="${csrfToken}">
            <input type="hidden" name="id" value="${customer.id}">
            <input type="hidden" name="status" value="${customer.status == 'ACTIVE' ? 'INACTIVE' : 'ACTIVE'}">
            <button class="btn btn-danger" type="submit"
                    data-confirm="Set customer to ${customer.status == 'ACTIVE' ? 'INACTIVE' : 'ACTIVE'}?">
                ${customer.status == 'ACTIVE' ? 'Deactivate customer' : 'Activate customer'}
            </button>
        </form>
    </div>
    <div class="panel">
        <h3>Bookings</h3>
        <div class="table-wrap" style="box-shadow:none;border:0;">
            <table>
                <thead>
                <tr><th>Code</th><th>Turf</th><th>Date</th><th>Status</th></tr>
                </thead>
                <tbody>
                <c:forEach var="b" items="${bookings}">
                    <tr>
                        <td><a href="${ctx}/admin/bookings/${b.id}">${b.bookingCode}</a></td>
                        <td><c:out value="${b.turfName}"/></td>
                        <td>${b.bookingDateFormatted}</td>
                        <td>${b.status}</td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
            <c:if test="${empty bookings}"><p class="muted">No bookings for this customer.</p></c:if>
        </div>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
