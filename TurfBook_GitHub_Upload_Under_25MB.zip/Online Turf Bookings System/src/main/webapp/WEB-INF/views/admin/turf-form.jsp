<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="${mode == 'edit' ? 'Edit Turf' : 'Add Turf'}" scope="request"/>
<c:set var="pageHeading" value="${mode == 'edit' ? 'Edit Turf' : 'Add Turf'}" scope="request"/>
<c:set var="activeNav" value="turfs" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="panel" style="max-width:720px;">
    <%-- enctype MUST be multipart/form-data for file upload --%>
    <form method="post"
          action="${ctx}/admin/turfs${mode == 'edit' ? '' : '/new'}"
          enctype="multipart/form-data">
        <input type="hidden" name="_csrf"   value="${csrfToken}">
        <input type="hidden" name="action"  value="${mode == 'edit' ? 'update' : 'create'}">
        <c:if test="${mode == 'edit'}">
            <input type="hidden" name="id" value="${turf.id}">
        </c:if>

        <div class="form-group">
            <label for="name">Turf name</label>
            <input id="name" name="name" value="${turf.name}" required>
        </div>
        <div class="form-group">
            <label for="location">Location</label>
            <input id="location" name="location" value="${turf.location}" required>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" required>${turf.description}</textarea>
        </div>
        <div class="form-group">
            <label for="pricePerHour">Price per hour (₹)</label>
            <input id="pricePerHour" name="pricePerHour" type="number" min="1" step="1"
                   value="${turf.pricePerHour}" required>
        </div>
        <div class="filters">
            <div class="form-group">
                <label for="openingTime">Opening time</label>
                <input id="openingTime" name="openingTime" type="time" step="3600"
                       value="${turf != null ? turf.openingTimeFormatted : '06:00'}" required>
            </div>
            <div class="form-group">
                <label for="closingTime">Closing time</label>
                <input id="closingTime" name="closingTime" type="time" step="3600"
                       value="${turf != null ? turf.closingTimeFormatted : '22:00'}" required>
            </div>
        </div>
        <div class="form-group">
            <label for="amenities">Amenities (comma-separated)</label>
            <input id="amenities" name="amenities" value="${turf.amenities}" required
                   placeholder="Floodlights, Changing rooms, Parking">
        </div>

        <%-- ─── Turf Image Upload ──────────────────────────────────────────── --%>
        <div class="form-group">
            <label>Turf image</label>

            <%-- Current image preview (edit mode only, when an image exists) --%>
            <c:if test="${mode == 'edit' and not empty turf.imagePath}">
                <div id="currentImageWrap" class="img-upload-current">
                    <img id="currentImg"
                         src="${ctx}/${turf.imagePath}"
                         alt="Current turf image"
                         class="img-upload-preview"
                         onerror="document.getElementById('currentImageWrap').style.display='none';">
                    <p class="form-hint">Current image — select a new file below to replace it.</p>
                </div>
            </c:if>

            <%-- File picker + new-image preview --%>
            <div class="img-upload-area" id="imgUploadArea">
                <label for="turfImage" class="img-upload-label" id="imgUploadLabel">
                    <span class="img-upload-icon" aria-hidden="true">📁</span>
                    <span id="imgUploadText">
                        <c:choose>
                            <c:when test="${mode == 'edit' and not empty turf.imagePath}">Choose new image</c:when>
                            <c:otherwise>Choose image</c:otherwise>
                        </c:choose>
                    </span>
                    <span class="img-upload-hint">JPG, PNG or WebP · max 5 MB</span>
                </label>
                <input type="file"
                       id="turfImage"
                       name="turfImage"
                       accept="image/jpeg,image/jpg,image/png,image/webp"
                       class="img-upload-input"
                       aria-describedby="imgTypeHint">
            </div>

            <%-- New image preview (shown by JS after file selection) --%>
            <div id="newImgPreviewWrap" class="img-upload-new" style="display:none;">
                <img id="newImgPreview" src="" alt="Selected image preview" class="img-upload-preview">
                <div class="img-upload-meta">
                    <span id="selectedFileName" class="img-upload-filename"></span>
                    <button type="button" id="clearImgBtn" class="btn btn-ghost btn-sm">Remove</button>
                </div>
            </div>

            <p id="imgTypeHint" class="form-hint">
                Leave empty to keep the colour gradient as the visual placeholder.
            </p>
        </div>
        <%-- ─────────────────────────────────────────────────────────────────── --%>

        <div class="form-group">
            <label for="imageColor">Visual accent color (used when no image is set)</label>
            <input id="imageColor" name="imageColor" type="color"
                   value="${turf != null ? turf.imageColor : '#1a5c3a'}">
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="ACTIVE"   ${turf == null || turf.status == 'ACTIVE'   ? 'selected' : ''}>ACTIVE</option>
                <option value="INACTIVE" ${turf.status == 'INACTIVE' ? 'selected' : ''}>INACTIVE</option>
            </select>
        </div>
        <button class="btn btn-primary" type="submit">
            ${mode == 'edit' ? 'Save changes' : 'Create turf'}
        </button>
        <a class="btn btn-secondary" href="${ctx}/admin/turfs">Cancel</a>
    </form>
</div>

<script>
(function () {
    var input       = document.getElementById('turfImage');
    var previewWrap = document.getElementById('newImgPreviewWrap');
    var previewImg  = document.getElementById('newImgPreview');
    var fileNameEl  = document.getElementById('selectedFileName');
    var clearBtn    = document.getElementById('clearImgBtn');
    var uploadArea  = document.getElementById('imgUploadArea');
    var uploadText  = document.getElementById('imgUploadText');

    var MAX_BYTES   = 5 * 1024 * 1024;          // 5 MB
    var ALLOWED     = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

    function showPreview(file) {
        var reader = new FileReader();
        reader.onload = function (e) {
            previewImg.src  = e.target.result;
            fileNameEl.textContent = file.name;
            previewWrap.style.display = 'block';
            uploadArea.style.display  = 'none';
        };
        reader.readAsDataURL(file);
    }

    function clearSelection() {
        input.value         = '';
        previewImg.src      = '';
        fileNameEl.textContent = '';
        previewWrap.style.display = 'none';
        uploadArea.style.display  = 'block';
    }

    input.addEventListener('change', function () {
        var file = input.files && input.files[0];
        if (!file) {
            clearSelection();
            return;
        }
        // Client-side type check (server always re-validates)
        if (ALLOWED.indexOf(file.type.toLowerCase()) === -1) {
            alert('Please select a JPG, PNG, or WebP image.');
            clearSelection();
            return;
        }
        // Client-side size check
        if (file.size > MAX_BYTES) {
            alert('The selected image is larger than 5 MB. Please choose a smaller file.');
            clearSelection();
            return;
        }
        showPreview(file);
    });

    clearBtn.addEventListener('click', function () {
        clearSelection();
    });
})();
</script>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
