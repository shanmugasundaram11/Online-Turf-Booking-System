<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Admin Profile" scope="request"/>
<c:set var="pageHeading" value="Profile" scope="request"/>
<c:set var="activeNav" value="profile" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<div class="detail-layout">
    <div class="panel">
        <h2>Profile details</h2>
        <form method="post" action="${ctx}/admin/profile">
            <input type="hidden" name="_csrf" value="${csrfToken}">
            <input type="hidden" name="action" value="profile">
            <div class="form-group">
                <label for="fullName">Full name</label>
                <input id="fullName" name="fullName" value="${profile.fullName}" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input id="email" value="${profile.email}" disabled>
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input id="phone" name="phone" value="${profile.phone}" required>
            </div>
            <button class="btn btn-primary" type="submit">Save changes</button>
        </form>
    </div>
    <div class="panel">
        <h2>Change password</h2>
        <form method="post" action="${ctx}/admin/profile" data-validate>
            <input type="hidden" name="_csrf" value="${csrfToken}">
            <input type="hidden" name="action" value="password">
            <div class="form-group">
                <label for="currentPassword">Current password</label>
                <input id="currentPassword" type="password" name="currentPassword" required>
            </div>
            <div class="form-group">
                <label for="newPassword">New password</label>
                <input id="newPassword" type="password" name="newPassword" required minlength="8">
            </div>
            <div class="form-group">
                <label for="confirmPassword">Confirm password</label>
                <input id="confirmPassword" type="password" name="confirmPassword" required>
            </div>
            <button class="btn btn-secondary" type="submit">Update password</button>
        </form>
    </div>
</div>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
