<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | TurfBook</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="${ctx}/images/favicon.svg">
    <link rel="stylesheet" href="${ctx}/css/main.css">
    <link rel="stylesheet" href="${ctx}/css/admin.css">
</head>
<body>
<div class="admin-login-wrap">
    <div class="admin-login-card">
        <div class="admin-login-brand">
            <a class="brand" href="${ctx}/home" aria-label="TurfBook Home">
                <span class="brand-mark" aria-hidden="true">
                    <img src="${ctx}/images/turfbook-crest.svg" alt="" class="brand-crest-img" width="44" height="44">
                </span>
                <span class="brand-text">
                    <span class="brand-turf">Turf</span><span class="brand-book">Book</span>
                </span>
            </a>
        </div>
        <p class="eyebrow">TurfBook operators</p>
        <h1>Admin login</h1>
        <p class="muted">Separate portal for turf and booking management.</p>
        <c:if test="${not empty error}">
            <div class="alert alert-error">${error}</div>
        </c:if>
        <form method="post" action="${ctx}/admin/login">
            <input type="hidden" name="_csrf" value="${csrfToken}">
            <div class="form-group">
                <label for="email">Admin email</label>
                <input id="email" type="email" name="email" value="${email}" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-field">
                    <input id="password" type="password" name="password" required>
                    <button type="button" data-password-toggle="#password">Show</button>
                </div>
            </div>
            <button class="btn btn-primary" style="width:100%;" type="submit">Sign in</button>
        </form>
        <p class="muted" style="margin-top:1rem;"><a href="${ctx}/home">← Back to website</a></p>
    </div>
</div>
<script src="${ctx}/js/main.js"></script>
</body>
</html>
