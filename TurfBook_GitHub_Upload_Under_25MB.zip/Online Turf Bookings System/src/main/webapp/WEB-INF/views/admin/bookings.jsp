<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Booking Management" scope="request"/>
<c:set var="pageHeading" value="Booking Management" scope="request"/>
<c:set var="activeNav" value="bookings" scope="request"/>
<%@ include file="/WEB-INF/views/common/admin-header.jsp" %>

<form class="filters" method="get" action="${ctx}/admin/bookings">
    <div class="form-group">
        <input type="search" name="q" value="${searchQuery}" placeholder="Search code, customer, turf...">
    </div>
    <div class="form-group">
        <select name="status">
            <option value="ALL">All statuses</option>
            <option value="CONFIRMED" ${statusFilter == 'CONFIRMED' ? 'selected' : ''}>Confirmed</option>
            <option value="CANCELLED" ${statusFilter == 'CANCELLED' ? 'selected' : ''}>Cancelled</option>
            <option value="COMPLETED" ${statusFilter == 'COMPLETED' ? 'selected' : ''}>Completed</option>
        </select>
    </div>
    <div class="form-group">
        <input type="date" name="from" value="${fromDate}" aria-label="From date">
    </div>
    <div class="form-group">
        <input type="date" name="to" value="${toDate}" aria-label="To date">
    </div>
    <button class="btn btn-secondary" type="submit">Apply</button>
</form>

<div class="table-wrap">
    <table>
        <thead>
        <tr>
            <th>Code</th>
            <th>Customer</th>
            <th>Turf</th>
            <th>Date</th>
            <th>Time</th>
            <th>Total</th>
            <th>Status</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="b" items="${bookings}">
            <tr>
                <td>${b.bookingCode}</td>
                <td><c:out value="${b.customerName}"/></td>
                <td><c:out value="${b.turfName}"/></td>
                <td>${b.bookingDateFormatted}</td>
                <td>${b.startTimeFormatted}–${b.endTimeFormatted}</td>
                <td>₹<fmt:formatNumber value="${b.totalAmount}" maxFractionDigits="0"/></td>
                <td>${b.status}</td>
                <td><a href="${ctx}/admin/bookings/${b.id}">Manage</a></td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
<c:if test="${empty bookings}">
    <div class="empty-state"><p>No bookings match your filters.</p></div>
</c:if>

<%@ include file="/WEB-INF/views/common/admin-footer.jsp" %>
