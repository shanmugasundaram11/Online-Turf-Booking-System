<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><c:out value="${pageTitle != null ? pageTitle : 'Admin'}"/> | TurfBook Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="${ctx}/images/favicon.svg">
    <link rel="stylesheet" href="${ctx}/css/main.css">
    <link rel="stylesheet" href="${ctx}/css/admin.css">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-sidebar" data-admin-sidebar>
        <a class="brand" href="${ctx}/admin/dashboard" aria-label="TurfBook Admin">
            <span class="brand-mark" aria-hidden="true">
                <img src="${ctx}/images/turfbook-crest.svg" alt="" class="brand-crest-img" width="38" height="38">
            </span>
            <span class="brand-text">
                <span class="brand-turf">Turf</span><span class="brand-book">Book</span>
            </span>
        </a>
        <p class="sidebar-label">Administration</p>
        <nav class="admin-nav">
            <a class="${activeNav == 'dashboard' ? 'active' : ''}" href="${ctx}/admin/dashboard">Dashboard</a>
            <a class="${activeNav == 'turfs' ? 'active' : ''}" href="${ctx}/admin/turfs">Turf Management</a>
            <a class="${activeNav == 'bookings' ? 'active' : ''}" href="${ctx}/admin/bookings">Booking Management</a>
            <a class="${activeNav == 'customers' ? 'active' : ''}" href="${ctx}/admin/customers">Customer Management</a>
            <a class="${activeNav == 'profile' ? 'active' : ''}" href="${ctx}/admin/profile">Profile</a>
            <button type="button" class="admin-nav-logout" data-logout-open aria-haspopup="dialog">Logout</button>
        </nav>
    </aside>

<c:if test="${currentUser != null}">
    <div id="logoutModal"
         class="dialog-backdrop"
         role="dialog"
         aria-modal="true"
         aria-labelledby="logoutModalTitle"
         aria-describedby="logoutModalDesc"
         hidden>
        <div class="dialog" tabindex="-1">
            <h2 id="logoutModalTitle" class="dialog-title">Log Out</h2>
            <p id="logoutModalDesc" class="dialog-message">Are you sure you want to log out of your admin account?</p>
            <div class="dialog-actions">
                <button type="button" class="btn btn-secondary" data-logout-cancel>Cancel</button>
                <form method="post" action="${ctx}/logout" class="inline-form">
                    <input type="hidden" name="_csrf" value="${csrfToken}">
                    <button type="submit" class="btn btn-primary" data-logout-confirm>Logout</button>
                </form>
            </div>
        </div>
    </div>
</c:if>

    <div class="admin-main">
        <header class="admin-topbar">
            <button class="nav-toggle admin-toggle" type="button" data-admin-toggle aria-label="Toggle menu">
                <span></span><span></span>
            </button>
            <div>
                <p class="eyebrow">Admin Portal</p>
                <h1 class="admin-page-title"><c:out value="${pageHeading != null ? pageHeading : 'Dashboard'}"/></h1>
            </div>
            <div class="admin-user">
                <span><c:out value="${currentUser.fullName}"/></span>
            </div>
        </header>

        <c:if test="${not empty flashSuccess}">
            <div class="toast toast-success" data-toast role="status">${flashSuccess}</div>
        </c:if>
        <c:if test="${not empty flashError}">
            <div class="toast toast-error" data-toast role="alert">${flashError}</div>
        </c:if>

        <div class="admin-content">
