<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><c:out value="${pageTitle != null ? pageTitle : 'TurfBook'}"/> | Online Turf Booking</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="${ctx}/images/favicon.svg">
    <link rel="stylesheet" href="${ctx}/css/main.css">
</head>
<body class="${bodyClass}">
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="${ctx}/home" aria-label="TurfBook Home">
            <span class="brand-mark" aria-hidden="true">
                <img src="${ctx}/images/turfbook-crest.svg" alt="" class="brand-crest-img" width="38" height="38">
            </span>
            <span class="brand-text">
                <span class="brand-turf">Turf</span><span class="brand-book">Book</span>
            </span>
        </a>
        <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Toggle navigation menu" data-nav-toggle>
            <span></span><span></span>
        </button>
        <nav id="primary-nav" class="primary-nav" data-nav>
            <a class="${activeNav == 'home' ? 'active' : ''}" href="${ctx}/home">Home</a>
            <a class="${activeNav == 'turfs' ? 'active' : ''}" href="${ctx}/turfs">Browse Turfs</a>
            <c:choose>
                <c:when test="${currentUser != null && currentUser.customer}">
                    <a class="${activeNav == 'dashboard' ? 'active' : ''}" href="${ctx}/customer/dashboard">Dashboard</a>
                    <a class="${activeNav == 'bookings' ? 'active' : ''}" href="${ctx}/bookings">My Bookings</a>
                    <a class="${activeNav == 'profile' ? 'active' : ''}" href="${ctx}/customer/profile">Profile</a>
                    <button type="button" class="btn btn-ghost" data-logout-open aria-haspopup="dialog">Logout</button>
                </c:when>
                <c:when test="${currentUser != null && currentUser.admin}">
                    <a href="${ctx}/admin/dashboard">Admin</a>
                    <button type="button" class="btn btn-ghost" data-logout-open aria-haspopup="dialog">Logout</button>
                </c:when>
                <c:otherwise>
                    <a class="${activeNav == 'login' ? 'active' : ''}" href="${ctx}/login">Login</a>
                    <a class="btn btn-primary" href="${ctx}/register">Get Started</a>
                </c:otherwise>
            </c:choose>
        </nav>
    </div>
</header>

<c:if test="${currentUser != null}">
    <div id="logoutModal"
         class="dialog-backdrop"
         role="dialog"
         aria-modal="true"
         aria-labelledby="logoutModalTitle"
         aria-describedby="logoutModalDesc"
         hidden>
        <div class="dialog" tabindex="-1">
            <h2 id="logoutModalTitle" class="dialog-title">Log Out</h2>
            <p id="logoutModalDesc" class="dialog-message">Are you sure you want to log out of your account?</p>
            <div class="dialog-actions">
                <button type="button" class="btn btn-secondary" data-logout-cancel>Cancel</button>
                <form method="post" action="${ctx}/logout" class="inline-form">
                    <input type="hidden" name="_csrf" value="${csrfToken}">
                    <button type="submit" class="btn btn-primary" data-logout-confirm>Logout</button>
                </form>
            </div>
        </div>
    </div>
</c:if>

<c:if test="${not empty flashSuccess}">
    <div class="toast toast-success" data-toast role="status">${flashSuccess}</div>
</c:if>
<c:if test="${not empty flashError}">
    <div class="toast toast-error" data-toast role="alert">${flashError}</div>
</c:if>

<main id="main">
