</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <a class="brand brand-footer" href="${ctx}/home" aria-label="TurfBook Home">
                <span class="brand-mark" aria-hidden="true">
                    <img src="${ctx}/images/turfbook-crest.svg" alt="" class="brand-crest-img" width="38" height="38">
                </span>
                <span class="brand-text">
                    <span class="brand-turf">Turf</span><span class="brand-book">Book</span>
                </span>
            </a>
            <p class="footer-tagline">Find. Book. Play. Premium turf booking for teams and players.</p>
        </div>
        <div>
            <h4>Explore</h4>
            <a href="${ctx}/turfs">Browse Turfs</a>
            <a href="${ctx}/register">Create Account</a>
            <a href="${ctx}/login">Customer Login</a>
        </div>
        <div>
            <h4>Operators</h4>
            <a href="${ctx}/admin/login">Admin Portal</a>
        </div>
    </div>
    <div class="container footer-bottom">
        <p>&copy; 2026 TurfBook. Built for demonstration and portfolio use.</p>
    </div>
</footer>
<script src="${ctx}/js/main.js"></script>
</body>
</html>
