<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Booking Details" scope="request"/>
<c:set var="activeNav" value="bookings" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Booking Receipt</span>
        <h1 class="page-title"><c:out value="${booking.bookingCode}"/></h1>
        <p class="section-copy">Official reservation confirmation for your upcoming sports turf session.</p>
    </div>
</section>

<section>
    <div class="container detail-layout">
        <!-- Left: Booking Receipt -->
        <div class="panel">
            <div style="border-bottom:1px solid var(--line); padding-bottom:1.15rem; margin-bottom:1.25rem;">
                <span class="eyebrow" style="margin-bottom:0.4rem;">Reserved Venue</span>
                <h2 style="margin:0 0 0.35rem; font-size:1.5rem;"><c:out value="${booking.turfName}"/></h2>
                <p class="muted" style="margin:0;"><c:out value="${booking.turfLocation}"/></p>
            </div>

            <div class="summary-card" style="margin:0;">
                <div class="summary-row">
                    <span>Booking Code</span>
                    <strong style="font-family:monospace; font-size:1.05rem; letter-spacing:0.02em;"><c:out value="${booking.bookingCode}"/></strong>
                </div>
                <div class="summary-row">
                    <span>Scheduled Date</span>
                    <strong>${booking.bookingDateFormatted}</strong>
                </div>
                <div class="summary-row">
                    <span>Session Time</span>
                    <strong>${booking.startTimeFormatted} &ndash; ${booking.endTimeFormatted}</strong>
                </div>
                <div class="summary-row">
                    <span>Duration</span>
                    <span>${booking.durationHours} hour(s)</span>
                </div>
                <div class="summary-row">
                    <span>Price / Hour</span>
                    <span>₹<fmt:formatNumber value="${booking.pricePerHour}" maxFractionDigits="0"/></span>
                </div>
                <div class="summary-row">
                    <span>Booking Status</span>
                    <span>
                        <c:choose>
                            <c:when test="${booking.status == 'CONFIRMED'}"><span class="badge badge-success">CONFIRMED</span></c:when>
                            <c:when test="${booking.status == 'CANCELLED'}"><span class="badge badge-danger">CANCELLED</span></c:when>
                            <c:otherwise><span class="badge badge-neutral">COMPLETED</span></c:otherwise>
                        </c:choose>
                    </span>
                </div>
                <div class="summary-row">
                    <span>Total Amount</span>
                    <strong style="color:var(--accent-dark); font-size:1.25rem;">₹<fmt:formatNumber value="${booking.totalAmount}" maxFractionDigits="0"/></strong>
                </div>
            </div>
        </div>

        <!-- Right: Actions & Policies -->
        <div class="panel">
            <h2>Reservation Actions</h2>
            <c:choose>
                <c:when test="${booking.cancellable}">
                    <div style="background:var(--bg-subtle); border:1px solid var(--line); border-radius:var(--radius-sm); padding:1.25rem; margin-bottom:1.25rem;">
                        <h3 style="font-size:1.05rem; margin:0 0 0.5rem; color:var(--ink);">Need to cancel?</h3>
                        <p class="muted" style="margin:0 0 1rem; font-size:0.88rem;">
                            Cancellations are allowed up to 2 hours before the start time. Cancelling will immediately release these hourly slots for other players.
                        </p>
                        <form method="post" action="${ctx}/bookings/${booking.id}">
                            <input type="hidden" name="_csrf" value="${csrfToken}">
                            <input type="hidden" name="action" value="cancel">
                            <button class="btn btn-danger" style="width:100%;" type="submit" data-confirm="Cancel this booking? Slots will become available again immediately.">
                                Cancel Booking
                            </button>
                        </form>
                    </div>
                </c:when>
                <c:otherwise>
                    <div style="background:var(--bg-subtle); border:1px solid var(--line); border-radius:var(--radius-sm); padding:1.25rem; margin-bottom:1.25rem;">
                        <span class="badge badge-neutral" style="margin-bottom:0.5rem;">Non-Cancellable</span>
                        <p class="muted" style="margin:0; font-size:0.88rem;">
                            Online cancellation is not available for this reservation because it has already started, is completed, or is within the 2-hour cutoff window.
                        </p>
                    </div>
                </c:otherwise>
            </c:choose>

            <div>
                <a class="btn btn-secondary" style="width:100%;" href="${ctx}/bookings">Back to My Bookings</a>
            </div>
        </div>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
