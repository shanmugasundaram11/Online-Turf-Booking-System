<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Customer Dashboard" scope="request"/>
<c:set var="activeNav" value="dashboard" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Customer Portal</span>
        <h1 class="page-title">Welcome back, <c:out value="${currentUser.fullName}"/></h1>
        <p class="section-copy">Manage your sports venue reservations, check upcoming matches, and book new hourly slots.</p>
    </div>
</section>

<section>
    <div class="container">
        <div class="stats-grid" style="margin-bottom:2rem;">
            <article class="stat-card">
                <p class="label">Total Bookings</p>
                <p class="value"><c:out value="${stats.userTotalBookings}"/></p>
            </article>
            <article class="stat-card">
                <p class="label">Upcoming Sessions</p>
                <p class="value"><c:out value="${stats.userActiveBookings}"/></p>
            </article>
            <article class="stat-card">
                <p class="label">Active Turfs</p>
                <p class="value"><c:out value="${stats.activeTurfs}"/></p>
            </article>
            <article class="stat-card stat-card-action">
                <p class="label">Quick Reserve</p>
                <div class="stat-card-action-body">
                    <a class="btn btn-primary btn-sm" href="${ctx}/turfs">Browse Turfs &rarr;</a>
                </div>
            </article>
        </div>

        <div class="dashboard-grid">
            <!-- Left: Upcoming & Recent Bookings -->
            <div style="display:flex; flex-direction:column; gap:1.75rem;">
                <div class="panel">
                    <h2>Next Upcoming Session</h2>
                    <c:choose>
                        <c:when test="${not empty upcomingBookings}">
                            <c:set var="next" value="${upcomingBookings[0]}"/>
                            <div class="upcoming-session-card">
                                <div>
                                    <div style="font-size:1.15rem; font-weight:700; color:var(--ink); margin-bottom:0.25rem;">
                                        <c:out value="${next.turfName}"/>
                                    </div>
                                    <div class="muted" style="margin-bottom:0.5rem;">
                                        ${next.bookingDateFormatted} &bull; ${next.startTimeFormatted} &ndash; ${next.endTimeFormatted}
                                    </div>
                                    <div>
                                        <span class="badge badge-success">${next.status}</span>
                                        <span class="muted" style="margin-left:0.5rem; font-size:0.85rem;">Code: <c:out value="${next.bookingCode}"/></span>
                                    </div>
                                </div>
                                <div>
                                    <a class="btn btn-secondary btn-sm" href="${ctx}/bookings/${next.id}">View Details</a>
                                </div>
                            </div>
                        </c:when>
                        <c:otherwise>
                            <div class="empty-state" style="padding:1.5rem; border-style:dashed;">
                                <p style="margin-bottom:0.75rem;">No upcoming bookings scheduled.</p>
                                <a class="btn btn-primary btn-sm" href="${ctx}/turfs">Book a Turf Now</a>
                            </div>
                        </c:otherwise>
                    </c:choose>
                </div>

                <div class="panel">
                    <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:1.15rem;">
                        <h2 style="margin:0;">Recent Bookings</h2>
                        <a class="muted" style="font-size:0.88rem; font-weight:600;" href="${ctx}/bookings">View all &rarr;</a>
                    </div>
                    <div class="table-wrap">
                        <table>
                            <thead>
                            <tr>
                                <th>Booking Code</th>
                                <th>Turf</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th class="text-right">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <c:forEach var="b" items="${recentBookings}">
                                <tr>
                                    <td><strong><c:out value="${b.bookingCode}"/></strong></td>
                                    <td><c:out value="${b.turfName}"/></td>
                                    <td>${b.bookingDateFormatted}</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${b.status == 'CONFIRMED'}"><span class="badge badge-success">CONFIRMED</span></c:when>
                                            <c:when test="${b.status == 'CANCELLED'}"><span class="badge badge-danger">CANCELLED</span></c:when>
                                            <c:otherwise><span class="badge badge-neutral">COMPLETED</span></c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="text-right">
                                        <a class="btn btn-secondary btn-sm" style="padding:0.3rem 0.75rem; min-height:32px; font-size:0.84rem;" href="${ctx}/bookings/${b.id}">Details</a>
                                    </td>
                                </tr>
                            </c:forEach>
                            </tbody>
                        </table>
                        <c:if test="${empty recentBookings}">
                            <div style="padding:1.5rem; text-align:center;" class="muted">No recent bookings found.</div>
                        </c:if>
                    </div>
                </div>
            </div>

            <!-- Right: Quick Actions & Profile Overview -->
            <div style="display:flex; flex-direction:column; gap:1.75rem;">
                <div class="panel">
                    <h2>Quick Actions</h2>
                    <div class="quick-actions">
                        <a class="btn btn-primary" href="${ctx}/turfs">Browse Turfs</a>
                        <a class="btn btn-secondary" href="${ctx}/bookings">My Bookings</a>
                        <a class="btn btn-secondary" href="${ctx}/customer/profile">Edit Profile</a>
                    </div>
                </div>

                <div class="panel">
                    <h2>Account Overview</h2>
                    <div style="display:flex; flex-direction:column; gap:0.65rem; font-size:0.92rem;">
                        <div class="summary-row" style="padding:0.4rem 0;">
                            <span>Player Name</span>
                            <strong><c:out value="${currentUser.fullName}"/></strong>
                        </div>
                        <div class="summary-row" style="padding:0.4rem 0;">
                            <span>Email</span>
                            <span class="muted"><c:out value="${currentUser.email}"/></span>
                        </div>
                        <div class="summary-row" style="padding:0.4rem 0;">
                            <span>Phone</span>
                            <span class="muted"><c:out value="${currentUser.phone}"/></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
