<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Profile" scope="request"/>
<c:set var="activeNav" value="profile" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Player Account</span>
        <h1 class="page-title">Profile Settings</h1>
        <p class="section-copy">Update your personal profile information and manage account security credentials.</p>
    </div>
</section>

<section>
    <div class="container detail-layout" style="padding-bottom:3.5rem;">
        <!-- Left: Personal Details Form -->
        <div class="panel">
            <h2>Personal Information</h2>
            <form method="post" action="${ctx}/customer/profile">
                <input type="hidden" name="_csrf" value="${csrfToken}">
                <input type="hidden" name="action" value="profile">

                <div class="form-group">
                    <label for="fullName">Full Name</label>
                    <input id="fullName" name="fullName" value="${profile.fullName}" required autocomplete="name">
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input id="email" value="${profile.email}" disabled aria-describedby="emailHint">
                    <p id="emailHint" class="form-hint">Email address cannot be changed once registered.</p>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input id="phone" name="phone" value="${profile.phone}" required pattern="[6-9][0-9]{9}" placeholder="10-digit mobile number" autocomplete="tel">
                    <p class="form-hint">Used for booking confirmations and schedule alerts.</p>
                </div>

                <button class="btn btn-primary" style="margin-top:0.5rem;" type="submit">Save Changes</button>
            </form>
        </div>

        <!-- Right: Change Password Form -->
        <div class="panel">
            <h2>Security Credentials</h2>
            <form method="post" action="${ctx}/customer/profile" data-validate>
                <input type="hidden" name="_csrf" value="${csrfToken}">
                <input type="hidden" name="action" value="password">

                <div class="form-group">
                    <label for="currentPassword">Current Password</label>
                    <div class="password-field">
                        <input id="currentPassword" type="password" name="currentPassword" required autocomplete="current-password" placeholder="Enter current password">
                        <button type="button" data-password-toggle="#currentPassword" aria-label="Toggle current password visibility">Show</button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="newPassword">New Password</label>
                    <div class="password-field">
                        <input id="newPassword" type="password" name="newPassword" required minlength="8" autocomplete="new-password" placeholder="At least 8 characters">
                        <button type="button" data-password-toggle="#newPassword" aria-label="Toggle new password visibility">Show</button>
                    </div>
                    <p class="form-hint">Must be at least 8 characters.</p>
                </div>

                <div class="form-group">
                    <label for="confirmPassword">Confirm New Password</label>
                    <div class="password-field">
                        <input id="confirmPassword" type="password" name="confirmPassword" required minlength="8" autocomplete="new-password" placeholder="Re-enter new password">
                        <button type="button" data-password-toggle="#confirmPassword" aria-label="Toggle confirm password visibility">Show</button>
                    </div>
                </div>

                <button class="btn btn-secondary" style="margin-top:0.5rem;" type="submit">Update Password</button>
            </form>
        </div>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
