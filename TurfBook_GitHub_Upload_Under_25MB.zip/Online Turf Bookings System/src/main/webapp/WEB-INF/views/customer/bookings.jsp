<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="My Bookings" scope="request"/>
<c:set var="activeNav" value="bookings" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Reservations</span>
        <h1 class="page-title">My Bookings</h1>
        <p class="section-copy">Review all your upcoming, completed, and cancelled sports turf reservations.</p>
    </div>
</section>

<section>
    <div class="container" style="padding-bottom:3.5rem;">
        <c:choose>
            <c:when test="${not empty bookings}">
                <div class="table-wrap">
                    <table>
                        <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Venue</th>
                            <th>Date</th>
                            <th>Time Window</th>
                            <th>Duration</th>
                            <th class="text-right">Total Amount</th>
                            <th class="text-center">Status</th>
                            <th class="text-right">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="b" items="${bookings}">
                            <tr>
                                <td>
                                    <strong style="letter-spacing:0.02em; font-family:monospace; font-size:0.95rem;"><c:out value="${b.bookingCode}"/></strong>
                                </td>
                                <td>
                                    <strong><c:out value="${b.turfName}"/></strong>
                                </td>
                                <td>${b.bookingDateFormatted}</td>
                                <td>${b.startTimeFormatted} &ndash; ${b.endTimeFormatted}</td>
                                <td>${b.durationHours} hr</td>
                                <td class="text-right">
                                    <strong style="color:var(--accent-dark); font-size:0.98rem;">₹<fmt:formatNumber value="${b.totalAmount}" maxFractionDigits="0"/></strong>
                                </td>
                                <td class="text-center">
                                    <c:choose>
                                        <c:when test="${b.status == 'CONFIRMED'}"><span class="badge badge-success">CONFIRMED</span></c:when>
                                        <c:when test="${b.status == 'CANCELLED'}"><span class="badge badge-danger">CANCELLED</span></c:when>
                                        <c:otherwise><span class="badge badge-neutral">COMPLETED</span></c:otherwise>
                                    </c:choose>
                                </td>
                                <td class="text-right">
                                    <a class="btn btn-secondary btn-sm" style="padding:0.35rem 0.85rem; min-height:32px; font-size:0.84rem;" href="${ctx}/bookings/${b.id}">Details</a>
                                </td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </c:when>
            <c:otherwise>
                <div class="empty-state">
                    <h3>No bookings found</h3>
                    <p>You haven't reserved any turfs yet. Browse our verified venues and book your first slot.</p>
                    <a class="btn btn-primary" href="${ctx}/turfs">Browse Turfs</a>
                </div>
            </c:otherwise>
        </c:choose>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
