<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<%
    request.setAttribute("ctx", request.getContextPath());
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access denied | TurfBook</title>
    <link rel="icon" type="image/svg+xml" href="${ctx}/images/favicon.svg">
    <link rel="stylesheet" href="${ctx}/css/main.css">
</head>
<body>
<main class="auth-layout">
    <div class="form-card" style="text-align:center;">
        <div style="display:flex; justify-content:center; margin-bottom:1.25rem;">
            <a class="brand" href="${ctx}/home" aria-label="TurfBook Home">
                <span class="brand-mark" aria-hidden="true">
                    <img src="${ctx}/images/turfbook-crest.svg" alt="" class="brand-crest-img" width="38" height="38">
                </span>
                <span class="brand-text">
                    <span class="brand-turf">Turf</span><span class="brand-book">Book</span>
                </span>
            </a>
        </div>
        <p class="eyebrow">403</p>
        <h1>Access denied</h1>
        <p class="muted">You do not have permission to view this page.</p>
        <a class="btn btn-primary" href="${ctx}/home">Go home</a>
    </div>
</main>
</body>
</html>
