<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%
    String ctx = request.getContextPath();
    request.setAttribute("ctx", ctx);
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page not found | TurfBook</title>
    <link rel="icon" type="image/svg+xml" href="${ctx}/images/favicon.svg">
    <link rel="stylesheet" href="${ctx}/css/main.css">
</head>
<body>
<main class="auth-layout">
    <div class="form-card" style="text-align:center;">
        <div style="display:flex; justify-content:center; margin-bottom:1.25rem;">
            <a class="brand" href="${ctx}/home" aria-label="TurfBook Home">
                <span class="brand-mark" aria-hidden="true">
                    <img src="${ctx}/images/turfbook-crest.svg" alt="" class="brand-crest-img" width="38" height="38">
                </span>
                <span class="brand-text">
                    <span class="brand-turf">Turf</span><span class="brand-book">Book</span>
                </span>
            </a>
        </div>
        <p class="eyebrow">404</p>
        <h1>Page not found</h1>
        <p class="muted">The page you requested does not exist or has moved.</p>
        <a class="btn btn-primary" href="${ctx}/home">Go home</a>
    </div>
</main>
</body>
</html>
