<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Customer Login" scope="request"/>
<c:set var="activeNav" value="login" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="auth-layout">
    <div class="form-card">
        <span class="eyebrow">Customer Access</span>
        <h1>Welcome Back</h1>
        <p class="muted" style="margin-bottom:1.5rem;">Log in to manage bookings, view match schedules, and reserve turfs.</p>

        <c:if test="${not empty error}">
            <div class="alert alert-error" role="alert">${error}</div>
        </c:if>

        <form method="post" action="${ctx}/login" data-validate>
            <input type="hidden" name="_csrf" value="${csrfToken}">
            <input type="hidden" name="redirect" value="${redirect}">

            <div class="form-group">
                <label for="email">Email Address</label>
                <input id="email" type="email" name="email" value="${email}" required autocomplete="email" placeholder="you@example.com">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-field">
                    <input id="password" type="password" name="password" required autocomplete="current-password" placeholder="Enter your password">
                    <button type="button" data-password-toggle="#password" aria-label="Toggle password visibility">Show</button>
                </div>
            </div>

            <button class="btn btn-primary" style="width:100%; margin-top:0.5rem;" type="submit">Sign In</button>
        </form>

        <div style="margin-top:1.5rem; padding-top:1rem; border-top:1px solid var(--line); font-size:0.92rem; text-align:center;">
            <p class="muted" style="margin:0 0 0.5rem;">New player? <a href="${ctx}/register"><strong>Create an account</strong></a></p>
            <p class="muted" style="margin:0;">Facility operator? <a href="${ctx}/admin/login"><strong>Admin portal</strong></a></p>
        </div>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
