<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Create Account" scope="request"/>
<c:set var="activeNav" value="register" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="auth-layout">
    <div class="form-card">
        <span class="eyebrow">Get Started</span>
        <h1>Create Account</h1>
        <p class="muted" style="margin-bottom:1.5rem;">Join TurfBook to find and reserve verified sports turfs in seconds.</p>

        <c:if test="${not empty error}">
            <div class="alert alert-error" role="alert">${error}</div>
        </c:if>

        <form method="post" action="${ctx}/register" data-validate>
            <input type="hidden" name="_csrf" value="${csrfToken}">

            <div class="form-group">
                <label for="fullName">Full Name</label>
                <input id="fullName" name="fullName" value="${fullName}" required minlength="2" autocomplete="name" placeholder="John Doe">
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input id="email" type="email" name="email" value="${email}" required autocomplete="email" placeholder="you@example.com">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input id="phone" name="phone" value="${phone}" required pattern="[6-9][0-9]{9}" placeholder="10-digit mobile (e.g. 9876543210)" autocomplete="tel">
                <p class="form-hint">Used for match updates and schedule alerts.</p>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-field">
                    <input id="password" type="password" name="password" required minlength="8" autocomplete="new-password" placeholder="At least 8 characters">
                    <button type="button" data-password-toggle="#password" aria-label="Toggle password visibility">Show</button>
                </div>
                <p class="form-hint">Minimum 8 characters with letters and numbers.</p>
            </div>

            <div class="form-group">
                <label for="confirmPassword">Confirm Password</label>
                <input id="confirmPassword" type="password" name="confirmPassword" required minlength="8" autocomplete="new-password" placeholder="Re-enter your password">
            </div>

            <button class="btn btn-primary" style="width:100%; margin-top:0.5rem;" type="submit">Create Account</button>
        </form>

        <div style="margin-top:1.5rem; padding-top:1rem; border-top:1px solid var(--line); font-size:0.92rem; text-align:center;">
            <p class="muted" style="margin:0;">Already have an account? <a href="${ctx}/login"><strong>Log in</strong></a></p>
        </div>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
