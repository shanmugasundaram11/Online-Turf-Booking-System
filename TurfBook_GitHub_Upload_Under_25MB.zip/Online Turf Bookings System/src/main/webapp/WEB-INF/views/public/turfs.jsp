<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Browse Turfs" scope="request"/>
<c:set var="activeNav" value="turfs" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Available Pitches</span>
        <h1 class="page-title">Browse Sports Turfs</h1>
        <p class="section-copy">Search verified sports venues by name, location, or amenities, and reserve your preferred hourly slot.</p>
        <form class="search-bar" method="get" action="${ctx}/turfs" role="search">
            <input type="search" name="q" value="${searchQuery}" placeholder="Search by turf name, location, or amenities..." aria-label="Search turfs">
            <button class="btn btn-primary" type="submit">Search</button>
            <c:if test="${not empty searchQuery}">
                <a class="btn btn-secondary" href="${ctx}/turfs">Clear</a>
            </c:if>
        </form>
    </div>
</section>

<section class="section" style="padding-top:0.5rem; padding-bottom:3.5rem;">
    <div class="container">
        <c:if test="${not empty error}">
            <div class="alert alert-error" role="alert">${error}</div>
        </c:if>

        <div style="margin-bottom:1.5rem; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
            <p class="muted" style="margin:0;">
                <c:choose>
                    <c:when test="${not empty searchQuery}">
                        Search results for <strong>&ldquo;<c:out value="${searchQuery}"/>&rdquo;</strong> &bull; <c:out value="${turfs.size()}"/> venue<c:if test="${turfs.size() != 1}">s</c:if> found
                    </c:when>
                    <c:otherwise>
                        Showing all verified active turfs &bull; <c:out value="${turfs.size()}"/> venue<c:if test="${turfs.size() != 1}">s</c:if> available
                    </c:otherwise>
                </c:choose>
            </p>
        </div>

        <div class="card-grid">
            <c:forEach var="turf" items="${turfs}">
                <article class="turf-card">
                    <c:choose>
                        <c:when test="${not empty turf.imagePath}">
                            <div class="turf-visual turf-visual-img">
                                <img src="${ctx}/${turf.imagePath}"
                                     alt="${turf.name}"
                                     class="turf-img"
                                     onerror="this.parentElement.classList.remove('turf-visual-img');this.parentElement.style.background='linear-gradient(145deg,${turf.imageColor},#111411)';this.remove();">
                                <span class="badge badge-success">Available</span>
                            </div>
                        </c:when>
                        <c:otherwise>
                            <div class="turf-visual" style="background: linear-gradient(145deg, ${turf.imageColor}, #111411);">
                                <span class="badge badge-success">Available</span>
                            </div>
                        </c:otherwise>
                    </c:choose>
                    <div class="turf-body">
                        <h3><c:out value="${turf.name}"/></h3>
                        <div class="turf-meta">
                            <span class="turf-location" title="${turf.location}">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block; vertical-align:-1px; margin-right:3px; opacity:0.75;" aria-hidden="true">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                    <circle cx="12" cy="10" r="3"></circle>
                                </svg>
                                <c:out value="${turf.location}"/>
                            </span>
                            <span class="price">₹<fmt:formatNumber value="${turf.pricePerHour}" maxFractionDigits="0"/>/hr</span>
                        </div>
                        <p class="muted"><c:out value="${turf.shortDescription}"/></p>
                        <div class="turf-actions">
                            <a class="btn btn-secondary btn-sm" href="${ctx}/turfs/${turf.id}">View Details</a>
                            <a class="btn btn-primary btn-sm" href="${ctx}/turfs/${turf.id}">Book Now</a>
                        </div>
                    </div>
                </article>
            </c:forEach>
        </div>
        <c:if test="${empty turfs}">
            <div class="empty-state">
                <h3>No turfs found</h3>
                <p>
                    <c:choose>
                        <c:when test="${not empty searchQuery}">
                            No venues matched &ldquo;<c:out value="${searchQuery}"/>&rdquo;. Try searching for an area or clear the search filter.
                        </c:when>
                        <c:otherwise>
                            No active turfs are currently listed. Please check back shortly.
                        </c:otherwise>
                    </c:choose>
                </p>
                <c:if test="${not empty searchQuery}">
                    <a class="btn btn-primary" href="${ctx}/turfs">View All Turfs</a>
                </c:if>
            </div>
        </c:if>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
