<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="${turf.name}" scope="request"/>
<c:set var="activeNav" value="turfs" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow"><c:out value="${turf.location}"/></span>
        <h1 class="page-title"><c:out value="${turf.name}"/></h1>
        <p class="section-copy"><c:out value="${turf.description}"/></p>
    </div>
</section>

<section>
    <div class="container detail-layout">
        <!-- Left Column: Venue Details -->
        <div class="panel">
            <c:choose>
                <c:when test="${not empty turf.imagePath}">
                    <div class="turf-visual turf-visual-img" style="height:280px;border-radius:var(--radius);margin-bottom:1.5rem;">
                        <img src="${ctx}/${turf.imagePath}"
                             alt="${turf.name}"
                             class="turf-img"
                             onerror="this.parentElement.classList.remove('turf-visual-img');this.parentElement.style.background='linear-gradient(145deg,${turf.imageColor},#111411)';this.remove();">
                        <span class="badge badge-success">Open ${turf.openingTimeFormatted} – ${turf.closingTimeFormatted}</span>
                    </div>
                </c:when>
                <c:otherwise>
                    <div class="turf-visual" style="height:280px;border-radius:var(--radius);margin-bottom:1.5rem;background:linear-gradient(145deg, ${turf.imageColor}, #111411);">
                        <span class="badge badge-success">Open ${turf.openingTimeFormatted} – ${turf.closingTimeFormatted}</span>
                    </div>
                </c:otherwise>
            </c:choose>

            <div class="turf-meta" style="margin-bottom:1.25rem; align-items:center; padding-bottom:1rem; border-bottom:1px solid var(--line);">
                <div>
                    <span style="font-size:0.86rem; color:var(--ink-soft); display:block;">Pricing</span>
                    <span class="price" style="font-size:1.45rem;">₹<fmt:formatNumber value="${turf.pricePerHour}" maxFractionDigits="0"/></span>
                    <span class="muted" style="font-size:0.9rem;"> / hour</span>
                </div>
                <div>
                    <span class="badge badge-success">Verified Venue</span>
                </div>
            </div>

            <div style="margin-bottom:1.5rem;">
                <h3 style="margin-bottom:0.6rem;">About This Turf</h3>
                <p class="muted" style="margin:0;"><c:out value="${turf.description}"/></p>
            </div>

            <div style="margin-bottom:1.5rem;">
                <h3 style="margin-bottom:0.6rem;">Amenities</h3>
                <c:choose>
                    <c:when test="${not empty turf.amenityList}">
                        <ul class="amenity-list">
                            <c:forEach var="a" items="${turf.amenityList}">
                                <li><c:out value="${a}"/></li>
                            </c:forEach>
                        </ul>
                    </c:when>
                    <c:otherwise>
                        <p class="muted" style="margin:0;">Standard turf amenities available.</p>
                    </c:otherwise>
                </c:choose>
            </div>

            <div>
                <h3 style="margin-bottom:0.4rem;">Operating Hours</h3>
                <p class="muted" style="margin:0;">Open daily from <strong>${turf.openingTimeFormatted}</strong> to <strong>${turf.closingTimeFormatted}</strong>.</p>
            </div>
        </div>

        <!-- Right Column: Booking Section -->
        <div class="panel" data-booking-root
             data-turf-id="${turf.id}"
             data-price="${turf.pricePerHour}"
             data-ctx="${ctx}">
            <h2>Book This Turf</h2>
            <p class="muted" style="margin-top:-0.5rem; margin-bottom:1.25rem;">Select your preferred date and consecutive hours below.</p>

            <c:choose>
                <c:when test="${currentUser == null}">
                    <div style="background:var(--bg-subtle); border:1px solid var(--line); border-radius:var(--radius-sm); padding:1.5rem; text-align:center;">
                        <p style="margin:0 0 1rem; color:var(--ink); font-weight:600;">Sign in to check live slots and reserve this pitch.</p>
                        <a class="btn btn-primary" style="width:100%; margin-bottom:0.5rem;" href="${ctx}/login?redirect=/turfs/${turf.id}">Login to Book</a>
                        <p class="muted" style="margin:0; font-size:0.88rem;">New player? <a href="${ctx}/register"><strong>Create an account</strong></a></p>
                    </div>
                </c:when>
                <c:when test="${currentUser.admin}">
                    <div class="alert alert-error">
                        Admin accounts cannot create customer bookings. Please log in with a customer account.
                    </div>
                </c:when>
                <c:otherwise>
                    <form id="bookingForm" method="post" action="${ctx}/turfs/${turf.id}">
                        <input type="hidden" name="_csrf" value="${csrfToken}">
                        <input type="hidden" name="selectedHours" id="selectedHours" value="">

                        <div class="form-group">
                            <label for="bookingDate">Select Date</label>
                            <input type="date" id="bookingDate" name="bookingDate" value="${selectedDate}" min="${minDate}" required>
                        </div>

                        <div>
                            <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:0.35rem;">
                                <label style="margin:0; font-weight:600; font-size:0.9rem;">Available Time Slots</label>
                                <span class="muted" style="font-size:0.8rem;">Consecutive hours only</span>
                            </div>
                            <p class="form-hint" style="margin-bottom:0.6rem;">Click slots to select or deselect.</p>

                            <p class="alert alert-error" data-slot-error hidden></p>
                            <p class="muted" data-slots-loading hidden style="padding:0.75rem 0; text-align:center;">Loading hourly availability…</p>

                            <div class="slot-grid" data-slot-grid>
                                <c:forEach var="slot" items="${slots}">
                                    <button type="button" class="slot-btn ${slot.available ? 'available' : 'unavailable'}"
                                            data-hour="${slot.hour}" ${slot.available ? '' : 'disabled'}>
                                        ${slot.label}
                                    </button>
                                </c:forEach>
                            </div>
                        </div>

                        <div class="summary-card">
                            <div class="summary-row">
                                <span>Selected Duration</span>
                                <strong data-summary-hours>—</strong>
                            </div>
                            <div class="summary-row">
                                <span>Reserved Time Range</span>
                                <strong data-summary-range>—</strong>
                            </div>
                            <div class="summary-row">
                                <span>Rate / Hour</span>
                                <span>₹<fmt:formatNumber value="${turf.pricePerHour}" maxFractionDigits="0"/></span>
                            </div>
                            <div class="summary-row">
                                <span>Total Payable</span>
                                <span data-summary-total>₹0</span>
                            </div>
                        </div>

                        <button class="btn btn-primary" style="width:100%; margin-top:0.75rem;" type="submit" data-booking-submit disabled>
                            Confirm Booking
                        </button>
                        <p class="form-hint" style="text-align:center; margin-top:0.65rem;">
                            Free cancellation up to 2 hours before your scheduled start time.
                        </p>
                    </form>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
