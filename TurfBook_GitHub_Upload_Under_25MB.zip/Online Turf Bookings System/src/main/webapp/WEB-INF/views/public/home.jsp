<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Find. Book. Play." scope="request"/>
<c:set var="bodyClass" value="home-page" scope="request"/>
<c:set var="activeNav" value="home" scope="request"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>

<section class="hero">
    <div class="container hero-grid">
        <div>
            <span class="eyebrow">Verified Sports Venues</span>
            <h1>Find. Book. Play.</h1>
            <p class="hero-copy">
                Easy online turf booking for football, cricket, and weekend matches.
                Find a turf near you, select available date and hourly time-slots, and book instantly.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary" href="${ctx}/turfs">Browse Turfs</a>
                <c:choose>
                    <c:when test="${currentUser != null && currentUser.customer}">
                        <a class="btn btn-secondary" href="${ctx}/customer/dashboard">My Dashboard</a>
                    </c:when>
                    <c:otherwise>
                        <a class="btn btn-secondary" href="${ctx}/register">Create Free Account</a>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
        <div class="hero-visual" aria-hidden="true">
            <div class="hero-visual-header">
                <strong>Quick Turf Reservation</strong>
                <span class="badge badge-success">Live Availability</span>
            </div>
            <div class="hero-visual-features">
                <div class="hero-visual-item">
                    <span class="hero-visual-item-icon">1</span>
                    <div>
                        <strong>Find your preferred venue</strong>
                        <div class="muted">Explore verified turfs across top locations with transparent pricing.</div>
                    </div>
                </div>
                <div class="hero-visual-item">
                    <span class="hero-visual-item-icon">2</span>
                    <div>
                        <strong>Select date & hourly slots</strong>
                        <div class="muted">Check real-time opening hours and pick consecutive slots.</div>
                    </div>
                </div>
                <div class="hero-visual-item">
                    <span class="hero-visual-item-icon">3</span>
                    <div>
                        <strong>Instant booking confirmation</strong>
                        <div class="muted">Conflict-free atomic reservation ensures no double bookings.</div>
                    </div>
                </div>
            </div>
            <div class="hero-visual-badge">
                <span>Atomic Hourly Locking</span>
                <strong style="color:var(--accent);">Instant Confirmation</strong>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow">At a glance</span>
                <h2 class="section-title">Trusted by local players</h2>
            </div>
        </div>
        <div class="stats-grid">
            <article class="stat-card">
                <p class="label">Active turfs</p>
                <p class="value"><c:out value="${stats.activeTurfs}"/></p>
            </article>
            <article class="stat-card">
                <p class="label">Total bookings</p>
                <p class="value"><c:out value="${stats.totalBookings}"/></p>
            </article>
            <article class="stat-card">
                <p class="label">Registered players</p>
                <p class="value"><c:out value="${stats.totalCustomers}"/></p>
            </article>
            <article class="stat-card">
                <p class="label">Confirmed sessions</p>
                <p class="value"><c:out value="${stats.confirmedBookings}"/></p>
            </article>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow">Featured venues</span>
                <h2 class="section-title">Turfs worth showing up for</h2>
            </div>
            <a class="btn btn-secondary btn-sm" href="${ctx}/turfs">View all turfs</a>
        </div>
        <div class="card-grid">
            <c:forEach var="turf" items="${featuredTurfs}">
                <article class="turf-card">
                    <c:choose>
                        <c:when test="${not empty turf.imagePath}">
                            <div class="turf-visual turf-visual-img">
                                <img src="${ctx}/${turf.imagePath}"
                                     alt="${turf.name}"
                                     class="turf-img"
                                     onerror="this.parentElement.classList.remove('turf-visual-img');this.parentElement.style.background='linear-gradient(145deg,${turf.imageColor},#111411)';this.remove();">
                                <span class="badge badge-success">Available</span>
                            </div>
                        </c:when>
                        <c:otherwise>
                            <div class="turf-visual" style="background: linear-gradient(145deg, ${turf.imageColor}, #111411);">
                                <span class="badge badge-success">Available</span>
                            </div>
                        </c:otherwise>
                    </c:choose>
                    <div class="turf-body">
                        <h3><c:out value="${turf.name}"/></h3>
                        <div class="turf-meta">
                            <span class="turf-location" title="${turf.location}">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block; vertical-align:-1px; margin-right:3px; opacity:0.75;" aria-hidden="true">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                    <circle cx="12" cy="10" r="3"></circle>
                                </svg>
                                <c:out value="${turf.location}"/>
                            </span>
                            <span class="price">₹<fmt:formatNumber value="${turf.pricePerHour}" maxFractionDigits="0"/>/hr</span>
                        </div>
                        <p class="muted"><c:out value="${turf.shortDescription}"/></p>
                        <div class="turf-actions">
                            <a class="btn btn-secondary btn-sm" href="${ctx}/turfs/${turf.id}">View Details</a>
                            <a class="btn btn-primary btn-sm" href="${ctx}/turfs/${turf.id}">Book Now</a>
                        </div>
                    </div>
                </article>
            </c:forEach>
            <c:if test="${empty featuredTurfs}">
                <div class="empty-state" style="grid-column: 1 / -1;">
                    <h3>No turfs available yet</h3>
                    <p>Venues will appear here once active pitches are added.</p>
                </div>
            </c:if>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow">How it works</span>
                <h2 class="section-title">Book in three clear steps</h2>
            </div>
        </div>
        <div class="steps-grid">
            <article class="step-card">
                <div class="step-number">1</div>
                <h3>Choose a turf</h3>
                <p class="muted">Compare locations, amenities, and hourly rates across verified sports venues.</p>
            </article>
            <article class="step-card">
                <div class="step-number">2</div>
                <h3>Pick your hours</h3>
                <p class="muted">Check real-time opening hours and select consecutive available hourly slots.</p>
            </article>
            <article class="step-card">
                <div class="step-number">3</div>
                <h3>Play with confidence</h3>
                <p class="muted">Receive immediate confirmation and manage your reservations effortlessly.</p>
            </article>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow">Why TurfBook</span>
                <h2 class="section-title">Built for real scheduling</h2>
            </div>
        </div>
        <div class="benefit-grid">
            <article class="benefit-card">
                <h3>Conflict-free slots</h3>
                <p class="muted">Transactional database locking prevents overlapping and double reservations.</p>
            </article>
            <article class="benefit-card">
                <h3>Transparent pricing</h3>
                <p class="muted">See exact total cost before confirming — price per hour multiplied by hours booked.</p>
            </article>
            <article class="benefit-card">
                <h3>Customer control</h3>
                <p class="muted">Cancel eligible bookings up to 2 hours before kickoff to automatically free slots.</p>
            </article>
        </div>
    </div>
</section>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
