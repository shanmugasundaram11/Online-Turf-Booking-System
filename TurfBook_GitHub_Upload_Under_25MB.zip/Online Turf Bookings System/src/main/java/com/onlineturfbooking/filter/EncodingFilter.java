package com.onlineturfbooking.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebFilter("/*")
public class EncodingFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        if (response instanceof HttpServletResponse httpResponse
                && request instanceof HttpServletRequest httpRequest) {
            String path = httpRequest.getRequestURI();
            if (path != null && (path.endsWith(".css") || path.endsWith(".js"))) {
                // leave content type to container for static assets
            } else if (!response.isCommitted() && response.getContentType() == null) {
                // servlets/jsp set their own types
            }
        }
        chain.doFilter(request, response);
    }
}
