package com.onlineturfbooking.filter;

import com.onlineturfbooking.dao.UserDao;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.util.CsrfUtil;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

@WebFilter("/*")
public class AuthFilter implements Filter {

    private final UserDao userDao = new UserDao();

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String path = req.getRequestURI().substring(req.getContextPath().length());
        if (path.isEmpty()) {
            path = "/";
        }

        HttpSession session = req.getSession(true);
        CsrfUtil.ensureToken(session);
        SessionUtil.exposeFlash(req);

        User user = SessionUtil.getUser(session);
        req.setAttribute("currentUser", user);
        req.setAttribute("csrfToken", session.getAttribute(CsrfUtil.CSRF_TOKEN_ATTR));
        req.setAttribute("ctx", req.getContextPath());

        if (isStaticOrPublic(path)) {
            chain.doFilter(request, response);
            return;
        }

        if (path.startsWith("/admin")) {
            if (user == null) {
                resp.sendRedirect(req.getContextPath() + "/admin/login");
                return;
            }
            if (!user.isAdmin()) {
                resp.sendRedirect(req.getContextPath() + "/access-denied");
                return;
            }
            chain.doFilter(request, response);
            return;
        }

        if (requiresCustomerAuth(path)) {
            if (user == null) {
                String redirect = req.getContextPath() + "/login";
                if ("GET".equalsIgnoreCase(req.getMethod())) {
                    redirect += "?redirect=" + java.net.URLEncoder.encode(path, java.nio.charset.StandardCharsets.UTF_8);
                }
                resp.sendRedirect(redirect);
                return;
            }
            if (!user.isCustomer()) {
                resp.sendRedirect(req.getContextPath() + "/access-denied");
                return;
            }
            // Verify the customer's account is still active in the database.
            // The User object stored in the session reflects status at login time only;
            // an admin may have deactivated the account since the session was created.
            try {
                User fresh = userDao.findById(user.getId()).orElse(null);
                if (fresh == null || !fresh.isActive()) {
                    SessionUtil.logout(session);
                    SessionUtil.setFlashError(req, "Your account has been deactivated. Please contact support.");
                    resp.sendRedirect(req.getContextPath() + "/login");
                    return;
                }
            } catch (SQLException e) {
                // DB lookup failed — fail safely: do not allow access in an uncertain state.
                SessionUtil.logout(session);
                SessionUtil.setFlashError(req, "Unable to verify your account. Please log in again.");
                resp.sendRedirect(req.getContextPath() + "/login");
                return;
            }
        }

        chain.doFilter(request, response);
    }

    private boolean isStaticOrPublic(String path) {
        if (path.startsWith("/css/") || path.startsWith("/js/") || path.startsWith("/images/")
                || path.startsWith("/assets/")) {
            return true;
        }
        return path.equals("/")
                || path.equals("/home")
                || path.equals("/turfs")
                || path.startsWith("/turfs/")
                || path.equals("/login")
                || path.equals("/register")
                || path.equals("/logout")
                || path.equals("/admin/login")
                || path.equals("/access-denied")
                || path.equals("/error")
                || path.startsWith("/api/availability");
    }

    private boolean requiresCustomerAuth(String path) {
        return path.startsWith("/customer")
                || path.startsWith("/bookings")
                || path.equals("/book")
                || path.equals("/profile");
    }
}
