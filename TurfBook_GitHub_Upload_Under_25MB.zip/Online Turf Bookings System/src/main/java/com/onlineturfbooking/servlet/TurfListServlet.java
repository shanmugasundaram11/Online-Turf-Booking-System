package com.onlineturfbooking.servlet;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.service.TurfService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "TurfListServlet", urlPatterns = "/turfs")
public class TurfListServlet extends HttpServlet {
    private final TurfService turfService = new TurfService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String search = req.getParameter("q");
        try {
            req.setAttribute("turfs", turfService.listActiveTurfs(search));
            req.setAttribute("searchQuery", search == null ? "" : search);
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
            req.setAttribute("turfs", java.util.List.of());
        }
        req.getRequestDispatcher("/WEB-INF/views/public/turfs.jsp").forward(req, resp);
    }
}
