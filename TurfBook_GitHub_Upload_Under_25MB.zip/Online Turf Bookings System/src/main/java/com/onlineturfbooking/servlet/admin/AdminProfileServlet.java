package com.onlineturfbooking.servlet.admin;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.service.AuthService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "AdminProfileServlet", urlPatterns = "/admin/profile")
public class AdminProfileServlet extends HttpServlet {
    private final AuthService authService = new AuthService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User sessionUser = SessionUtil.getUser(req);
        try {
            User user = authService.getUserById(sessionUser.getId());
            user.setPasswordHash(null);
            req.setAttribute("profile", user);
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.getRequestDispatcher("/WEB-INF/views/admin/profile.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User sessionUser = SessionUtil.getUser(req);
        String action = req.getParameter("action");
        try {
            if ("password".equals(action)) {
                authService.changePassword(sessionUser.getId(),
                        req.getParameter("currentPassword"),
                        req.getParameter("newPassword"),
                        req.getParameter("confirmPassword"));
                SessionUtil.setFlashSuccess(req, "Password updated successfully.");
            } else {
                authService.updateProfile(sessionUser.getId(),
                        req.getParameter("fullName"),
                        req.getParameter("phone"));
                User refreshed = authService.getUserById(sessionUser.getId());
                refreshed.setPasswordHash(null);
                SessionUtil.setUser(req.getSession(), refreshed);
                SessionUtil.setFlashSuccess(req, "Profile updated successfully.");
            }
        } catch (AppException e) {
            SessionUtil.setFlashError(req, e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/admin/profile");
    }
}
