package com.onlineturfbooking.servlet.customer;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.Booking;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "CustomerBookingDetailServlet", urlPatterns = "/bookings/*")
public class CustomerBookingDetailServlet extends HttpServlet {
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long id = extractId(req);
        if (id == null) {
            resp.sendRedirect(req.getContextPath() + "/bookings");
            return;
        }
        User user = SessionUtil.getUser(req);
        try {
            Booking booking = bookingService.getBookingForCustomer(id, user.getId());
            req.setAttribute("booking", booking);
            req.getRequestDispatcher("/WEB-INF/views/customer/booking-detail.jsp").forward(req, resp);
        } catch (AppException e) {
            SessionUtil.setFlashError(req, e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/bookings");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long id = extractId(req);
        User user = SessionUtil.getUser(req);
        if (id == null) {
            resp.sendRedirect(req.getContextPath() + "/bookings");
            return;
        }
        String action = req.getParameter("action");
        try {
            if ("cancel".equals(action)) {
                bookingService.cancelBooking(id, user.getId());
                SessionUtil.setFlashSuccess(req, "Booking cancelled successfully. Slots are now available again.");
            }
        } catch (AppException e) {
            SessionUtil.setFlashError(req, e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/bookings/" + id);
    }

    private Long extractId(HttpServletRequest req) {
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            return null;
        }
        try {
            return Long.parseLong(pathInfo.substring(1).split("/")[0]);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
