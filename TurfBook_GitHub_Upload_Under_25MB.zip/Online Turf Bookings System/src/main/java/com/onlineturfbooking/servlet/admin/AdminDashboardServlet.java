package com.onlineturfbooking.servlet.admin;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.service.DashboardService;
import com.onlineturfbooking.service.TurfService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "AdminDashboardServlet", urlPatterns = "/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {
    private final DashboardService dashboardService = new DashboardService();
    private final BookingService bookingService = new BookingService();
    private final TurfService turfService = new TurfService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("stats", dashboardService.getAdminStats());
            req.setAttribute("recentBookings", bookingService.getRecentBookings(8));
            req.setAttribute("turfs", turfService.listAllForAdmin(null, "ACTIVE"));
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(req, resp);
    }
}
