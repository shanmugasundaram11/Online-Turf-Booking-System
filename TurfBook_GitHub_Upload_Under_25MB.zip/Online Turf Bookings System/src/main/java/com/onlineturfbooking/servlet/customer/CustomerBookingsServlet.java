package com.onlineturfbooking.servlet.customer;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "CustomerBookingsServlet", urlPatterns = "/bookings")
public class CustomerBookingsServlet extends HttpServlet {
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = SessionUtil.getUser(req);
        try {
            req.setAttribute("bookings", bookingService.getCustomerBookings(user.getId()));
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
            req.setAttribute("bookings", java.util.List.of());
        }
        req.getRequestDispatcher("/WEB-INF/views/customer/bookings.jsp").forward(req, resp);
    }
}
