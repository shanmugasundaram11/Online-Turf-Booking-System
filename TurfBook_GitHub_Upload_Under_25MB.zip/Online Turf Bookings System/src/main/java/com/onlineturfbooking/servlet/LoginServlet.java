package com.onlineturfbooking.servlet;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.model.UserRole;
import com.onlineturfbooking.service.AuthService;
import com.onlineturfbooking.util.CsrfUtil;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    private final AuthService authService = new AuthService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = SessionUtil.getUser(req);
        if (user != null) {
            resp.sendRedirect(req.getContextPath() + (user.isAdmin() ? "/admin/dashboard" : "/customer/dashboard"));
            return;
        }
        req.setAttribute("redirect", req.getParameter("redirect"));
        req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String redirect = req.getParameter("redirect");
        try {
            User user = authService.login(email, password, UserRole.CUSTOMER);
            HttpSession old = req.getSession(false);
            if (old != null) {
                old.invalidate();
            }
            HttpSession session = req.getSession(true);
            SessionUtil.setUser(session, user);
            CsrfUtil.ensureToken(session);
            SessionUtil.setFlashSuccess(req, "Welcome back, " + user.getFullName() + "!");
            if (redirect != null && redirect.startsWith("/") && !redirect.startsWith("//")
                    && !redirect.startsWith("/admin")) {
                resp.sendRedirect(req.getContextPath() + redirect);
            } else {
                resp.sendRedirect(req.getContextPath() + "/customer/dashboard");
            }
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
            req.setAttribute("email", email);
            req.setAttribute("redirect", redirect);
            req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
        }
    }
}
