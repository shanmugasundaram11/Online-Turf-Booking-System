package com.onlineturfbooking.servlet.admin;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.BookingStatus;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;

@WebServlet(name = "AdminBookingServlet", urlPatterns = {"/admin/bookings", "/admin/bookings/*"})
public class AdminBookingServlet extends HttpServlet {
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        try {
            if (path != null && path.length() > 1) {
                long id = Long.parseLong(path.substring(1));
                req.setAttribute("booking", bookingService.getBooking(id));
                req.getRequestDispatcher("/WEB-INF/views/admin/booking-detail.jsp").forward(req, resp);
                return;
            }
            LocalDate from = parseDate(req.getParameter("from"));
            LocalDate to = parseDate(req.getParameter("to"));
            req.setAttribute("bookings", bookingService.searchBookings(
                    req.getParameter("q"), req.getParameter("status"), from, to));
            req.setAttribute("searchQuery", nullToEmpty(req.getParameter("q")));
            req.setAttribute("statusFilter", nullToEmpty(req.getParameter("status")));
            req.setAttribute("fromDate", nullToEmpty(req.getParameter("from")));
            req.setAttribute("toDate", nullToEmpty(req.getParameter("to")));
            req.getRequestDispatcher("/WEB-INF/views/admin/bookings.jsp").forward(req, resp);
        } catch (AppException | NumberFormatException e) {
            SessionUtil.setFlashError(req, e.getMessage() != null ? e.getMessage() : "Booking not found.");
            resp.sendRedirect(req.getContextPath() + "/admin/bookings");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            long id = Long.parseLong(req.getParameter("id"));
            BookingStatus status = BookingStatus.valueOf(req.getParameter("status"));
            bookingService.updateStatus(id, status);
            SessionUtil.setFlashSuccess(req, "Booking status updated to " + status + ".");
            resp.sendRedirect(req.getContextPath() + "/admin/bookings/" + id);
        } catch (Exception e) {
            SessionUtil.setFlashError(req, e.getMessage() != null ? e.getMessage() : "Unable to update booking.");
            resp.sendRedirect(req.getContextPath() + "/admin/bookings");
        }
    }

    private LocalDate parseDate(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return LocalDate.parse(value);
    }

    private String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}
