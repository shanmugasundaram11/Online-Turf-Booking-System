package com.onlineturfbooking.servlet.admin;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.model.UserStatus;
import com.onlineturfbooking.service.AuthService;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "AdminCustomerServlet", urlPatterns = {"/admin/customers", "/admin/customers/*"})
public class AdminCustomerServlet extends HttpServlet {
    private final AuthService authService = new AuthService();
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        try {
            if (path != null && path.length() > 1) {
                long id = Long.parseLong(path.substring(1));
                User customer = authService.getUserById(id);
                if (!customer.isCustomer()) {
                    throw new AppException("Customer not found.");
                }
                customer.setPasswordHash(null);
                req.setAttribute("customer", customer);
                req.setAttribute("bookings", bookingService.getCustomerBookings(id));
                req.getRequestDispatcher("/WEB-INF/views/admin/customer-detail.jsp").forward(req, resp);
                return;
            }
            req.setAttribute("customers", authService.listCustomers(req.getParameter("q")));
            req.setAttribute("searchQuery", req.getParameter("q") == null ? "" : req.getParameter("q"));
            req.getRequestDispatcher("/WEB-INF/views/admin/customers.jsp").forward(req, resp);
        } catch (AppException | NumberFormatException e) {
            SessionUtil.setFlashError(req, e.getMessage() != null ? e.getMessage() : "Customer not found.");
            resp.sendRedirect(req.getContextPath() + "/admin/customers");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            long id = Long.parseLong(req.getParameter("id"));
            UserStatus status = UserStatus.valueOf(req.getParameter("status"));
            authService.setCustomerStatus(id, status);
            SessionUtil.setFlashSuccess(req, "Customer status updated to " + status + ".");
            resp.sendRedirect(req.getContextPath() + "/admin/customers/" + id);
        } catch (Exception e) {
            SessionUtil.setFlashError(req, e.getMessage() != null ? e.getMessage() : "Unable to update customer.");
            resp.sendRedirect(req.getContextPath() + "/admin/customers");
        }
    }
}
