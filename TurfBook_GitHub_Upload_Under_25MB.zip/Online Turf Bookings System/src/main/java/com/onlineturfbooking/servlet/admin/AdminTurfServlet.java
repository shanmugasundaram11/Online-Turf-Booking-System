package com.onlineturfbooking.servlet.admin;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.Turf;
import com.onlineturfbooking.model.TurfStatus;
import com.onlineturfbooking.service.TurfService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Set;
import java.util.UUID;

/**
 * Admin turf management servlet.
 * Supports multipart/form-data for image file upload.
 * maxFileSize    = 5 MB per file
 * maxRequestSize = 6 MB total request
 * fileSizeThreshold = 0  (always write to disk, never buffer in memory)
 */
@WebServlet(name = "AdminTurfServlet", urlPatterns = {"/admin/turfs", "/admin/turfs/*"})
@MultipartConfig(
        maxFileSize      = 5 * 1024 * 1024,   // 5 MB
        maxRequestSize   = 6 * 1024 * 1024,   // 6 MB total
        fileSizeThreshold = 0
)
public class AdminTurfServlet extends HttpServlet {

    /** Allowed MIME types for turf images. */
    private static final Set<String> ALLOWED_TYPES = Set.of(
            "image/jpeg",
            "image/jpg",
            "image/png",
            "image/webp"
    );

    /** Relative path (from webapp root) where turf images are stored. */
    private static final String IMAGE_DIR_RELATIVE = "images/turfs";

    /** Sample image filenames — never delete these. */
    private static final Set<String> SAMPLE_IMAGES = Set.of(
            "turf1.jpg", "turf2.jpg", "turf3.jpg", "turf4.jpg", "turf5.jpg"
    );

    private final TurfService turfService = new TurfService();

    // ─── GET ─────────────────────────────────────────────────────────────────

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String path = pathInfo(req);
        try {
            if (path.equals("/") || path.isEmpty()) {
                req.setAttribute("turfs", turfService.listAllForAdmin(
                        req.getParameter("q"), req.getParameter("status")));
                req.setAttribute("searchQuery", nullToEmpty(req.getParameter("q")));
                req.setAttribute("statusFilter", nullToEmpty(req.getParameter("status")));
                req.getRequestDispatcher("/WEB-INF/views/admin/turfs.jsp").forward(req, resp);
                return;
            }
            if (path.equals("/new")) {
                req.setAttribute("mode", "create");
                req.getRequestDispatcher("/WEB-INF/views/admin/turf-form.jsp").forward(req, resp);
                return;
            }
            if (path.endsWith("/edit")) {
                long id = Long.parseLong(path.replace("/edit", "").replace("/", ""));
                Turf turf = turfService.getTurf(id);
                if (turf.isArchived()) {
                    SessionUtil.setFlashError(req, "Archived turfs cannot be edited. Please restore the turf first.");
                    resp.sendRedirect(req.getContextPath() + "/admin/turfs");
                    return;
                }
                req.setAttribute("turf", turf);
                req.setAttribute("mode", "edit");
                req.getRequestDispatcher("/WEB-INF/views/admin/turf-form.jsp").forward(req, resp);
                return;
            }
            long id = Long.parseLong(path.replace("/", ""));
            req.setAttribute("turf", turfService.getTurf(id));
            req.getRequestDispatcher("/WEB-INF/views/admin/turf-view.jsp").forward(req, resp);
        } catch (AppException | NumberFormatException e) {
            SessionUtil.setFlashError(req, e.getMessage() != null ? e.getMessage() : "Turf not found.");
            resp.sendRedirect(req.getContextPath() + "/admin/turfs");
        }
    }

    // ─── POST ────────────────────────────────────────────────────────────────

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String path    = pathInfo(req);
        String action  = req.getParameter("action");

        try {
            if ("create".equals(action) || path.equals("/new")) {
                String savedImagePath = handleImageUpload(req, null);
                long id;
                try {
                    id = turfService.createTurf(
                            req.getParameter("name"),
                            req.getParameter("location"),
                            req.getParameter("description"),
                            req.getParameter("pricePerHour"),
                            req.getParameter("openingTime"),
                            req.getParameter("closingTime"),
                            req.getParameter("amenities"),
                            savedImagePath,
                            req.getParameter("imageColor"),
                            parseStatus(req.getParameter("status")));
                } catch (AppException dbEx) {
                    // DB failed — delete orphaned file if we just saved one
                    deleteUploadedFile(req, savedImagePath);
                    throw dbEx;
                }
                SessionUtil.setFlashSuccess(req, "Turf created successfully.");
                resp.sendRedirect(req.getContextPath() + "/admin/turfs/" + id);
                return;
            }

            if ("update".equals(action)) {
                long id = Long.parseLong(req.getParameter("id"));
                Turf existing = turfService.getTurf(id);
                if (existing.isArchived()) {
                    throw new AppException("Archived turfs cannot be edited. Please restore the turf first.");
                }
                String oldImagePath = existing.getImagePath(); // may be null

                String savedImagePath = handleImageUpload(req, oldImagePath);
                try {
                    turfService.updateTurf(id,
                            req.getParameter("name"),
                            req.getParameter("location"),
                            req.getParameter("description"),
                            req.getParameter("pricePerHour"),
                            req.getParameter("openingTime"),
                            req.getParameter("closingTime"),
                            req.getParameter("amenities"),
                            savedImagePath,
                            req.getParameter("imageColor"),
                            parseStatus(req.getParameter("status")));
                } catch (AppException dbEx) {
                    // DB failed — if we just wrote a NEW file, delete it (orphan cleanup)
                    if (savedImagePath != null && !savedImagePath.equals(oldImagePath)) {
                        deleteUploadedFile(req, savedImagePath);
                    }
                    throw dbEx;
                }
                // DB succeeded and new image was uploaded — delete the OLD file (if safe)
                if (savedImagePath != null && !savedImagePath.equals(oldImagePath) && oldImagePath != null) {
                    safeDeleteOldImage(req, oldImagePath);
                }
                SessionUtil.setFlashSuccess(req, "Turf updated successfully.");
                resp.sendRedirect(req.getContextPath() + "/admin/turfs/" + id);
                return;
            }

            if ("toggle".equals(action)) {
                long id = Long.parseLong(req.getParameter("id"));
                Turf existing = turfService.getTurf(id);
                if (existing.isArchived()) {
                    throw new AppException("Cannot change status of an archived turf directly. Please restore it first.");
                }
                TurfStatus status = TurfStatus.valueOf(req.getParameter("status"));
                if (status == TurfStatus.ARCHIVED) {
                    throw new AppException("Cannot set status to ARCHIVED directly. Use the delete action to archive a turf.");
                }
                turfService.setStatus(id, status);
                SessionUtil.setFlashSuccess(req, "Turf status updated to " + status + ".");
                resp.sendRedirect(req.getContextPath() + "/admin/turfs");
                return;
            }

            if ("restore".equals(action)) {
                long id = Long.parseLong(req.getParameter("id"));
                Turf turf = turfService.getTurf(id);
                turfService.restoreTurf(id);
                SessionUtil.setFlashSuccess(req, "Turf \"" + turf.getName() + "\" was restored to INACTIVE status.");
                resp.sendRedirect(req.getContextPath() + "/admin/turfs");
                return;
            }

            if ("delete".equals(action)) {
                long id = Long.parseLong(req.getParameter("id"));
                TurfService.DeleteTurfResult result = turfService.deleteTurf(id);
                Turf targetTurf = result.getTurf();

                if (result.isPermanentlyDeleted()) {
                    String imagePath = targetTurf.getImagePath();
                    if (imagePath != null && !imagePath.isBlank()) {
                        try {
                            if (!turfService.isImagePathShared(imagePath, id)) {
                                safeDeleteOldImage(req, imagePath);
                            }
                        } catch (Exception ignored) {
                            // Non-critical image deletion error should not break successful turf deletion
                        }
                    }
                    SessionUtil.setFlashSuccess(req, "Turf \"" + targetTurf.getName() + "\" was successfully deleted.");
                } else {
                    // Soft-deleted / archived: keep image and records intact for historical receipts/references
                    SessionUtil.setFlashSuccess(req, "Turf \"" + targetTurf.getName() + "\" has existing booking history and was safely archived.");
                }

                resp.sendRedirect(req.getContextPath() + "/admin/turfs");
                return;
            }

            resp.sendRedirect(req.getContextPath() + "/admin/turfs");

        } catch (NumberFormatException e) {
            SessionUtil.setFlashError(req, "Invalid turf ID.");
            resp.sendRedirect(req.getContextPath() + "/admin/turfs");
        } catch (AppException e) {
            SessionUtil.setFlashError(req, e.getMessage() != null ? e.getMessage() : "Invalid request.");
            resp.sendRedirect(req.getContextPath() + "/admin/turfs");
        }
    }

    // ─── IMAGE UPLOAD ────────────────────────────────────────────────────────

    /**
     * Handles the turfImage file part.
     *
     * @param req           The current request (must be multipart).
     * @param existingPath  The turf's current image_path (may be null).
     * @return  The relative path to store in the DB, or {@code existingPath}
     *          if no new file was selected, or {@code null} if creating with no image.
     * @throws AppException if the file fails server-side validation.
     * @throws IOException  on I/O errors.
     * @throws ServletException on servlet errors.
     */
    private String handleImageUpload(HttpServletRequest req, String existingPath)
            throws AppException, IOException, ServletException {

        Part filePart = req.getPart("turfImage");

        // No part or empty submission — keep existing path (null on create)
        if (filePart == null || filePart.getSize() == 0) {
            return existingPath;
        }

        // ── Validate content type ──────────────────────────────────────────
        String submittedType = filePart.getContentType();
        if (submittedType == null || !ALLOWED_TYPES.contains(submittedType.toLowerCase().trim())) {
            throw new AppException(
                    "Invalid file type. Only JPG, PNG, and WebP images are allowed.");
        }

        // ── Validate size (belt-and-suspenders; @MultipartConfig also enforces) ──
        if (filePart.getSize() > 5L * 1024 * 1024) {
            throw new AppException("Image file is too large. Maximum allowed size is 5 MB.");
        }

        // ── Derive safe extension from content type ────────────────────────
        String ext = extensionFor(submittedType);

        // ── Generate collision-proof filename ─────────────────────────────
        String safeFilename = UUID.randomUUID().toString().replace("-", "") + ext;

        // ── Resolve absolute upload directory ─────────────────────────────
        String webappRoot = req.getServletContext().getRealPath("/");
        if (webappRoot == null) {
            throw new AppException("Upload directory is not accessible.");
        }
        Path uploadDir = Paths.get(webappRoot, IMAGE_DIR_RELATIVE);
        Files.createDirectories(uploadDir);

        // ── Security: prevent path traversal (UUID filenames already safe) ─
        Path target = uploadDir.resolve(safeFilename).normalize();
        if (!target.startsWith(uploadDir.normalize())) {
            throw new AppException("Invalid upload path.");
        }

        // ── Write file ────────────────────────────────────────────────────
        try (InputStream is = filePart.getInputStream()) {
            Files.copy(is, target, StandardCopyOption.REPLACE_EXISTING);
        }

        // Return the relative path that gets stored in the DB
        return IMAGE_DIR_RELATIVE + "/" + safeFilename;
    }

    /**
     * Derive a safe file extension from a validated MIME type.
     * Only called after ALLOWED_TYPES check so types are limited.
     */
    private String extensionFor(String mimeType) {
        return switch (mimeType.toLowerCase().trim()) {
            case "image/png"  -> ".png";
            case "image/webp" -> ".webp";
            default           -> ".jpg";   // image/jpeg, image/jpg
        };
    }

    /**
     * Deletes a newly-uploaded file to avoid orphans when the DB write fails.
     * Never deletes sample images.
     */
    private void deleteUploadedFile(HttpServletRequest req, String relativePath) {
        if (relativePath == null) {
            return;
        }
        safeDeleteOldImage(req, relativePath);
    }

    /**
     * Deletes an old image from disk, but NEVER deletes sample images.
     */
    private void safeDeleteOldImage(HttpServletRequest req, String relativePath) {
        if (relativePath == null) {
            return;
        }
        // Guard: never delete sample images
        String filename = Paths.get(relativePath).getFileName().toString();
        if (SAMPLE_IMAGES.contains(filename)) {
            return;
        }
        try {
            String webappRoot = req.getServletContext().getRealPath("/");
            if (webappRoot == null) {
                return;
            }
            Path uploadDir = Paths.get(webappRoot, IMAGE_DIR_RELATIVE).normalize();
            Path target    = Paths.get(webappRoot, relativePath).normalize();
            // Security: only delete if the resolved path is still inside the upload directory
            if (!target.startsWith(uploadDir)) {
                return;
            }
            Files.deleteIfExists(target);
        } catch (IOException | SecurityException e) {
            // Non-critical — log could be added here; do not break the flow
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private TurfStatus parseStatus(String status) {
        try {
            return TurfStatus.valueOf(status);
        } catch (Exception e) {
            return TurfStatus.ACTIVE;
        }
    }

    private String pathInfo(HttpServletRequest req) {
        String p = req.getPathInfo();
        return p == null ? "/" : p;
    }

    private String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}
