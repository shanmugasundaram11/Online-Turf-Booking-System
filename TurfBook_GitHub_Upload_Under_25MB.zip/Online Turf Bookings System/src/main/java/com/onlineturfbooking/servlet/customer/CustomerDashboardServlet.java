package com.onlineturfbooking.servlet.customer;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.service.DashboardService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "CustomerDashboardServlet", urlPatterns = "/customer/dashboard")
public class CustomerDashboardServlet extends HttpServlet {
    private final DashboardService dashboardService = new DashboardService();
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = SessionUtil.getUser(req);
        try {
            req.setAttribute("stats", dashboardService.getCustomerStats(user.getId()));
            req.setAttribute("upcomingBookings", bookingService.getUpcomingForCustomer(user.getId(), 3));
            req.setAttribute("recentBookings", bookingService.getCustomerBookings(user.getId()).stream().limit(5).toList());
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.getRequestDispatcher("/WEB-INF/views/customer/dashboard.jsp").forward(req, resp);
    }
}
