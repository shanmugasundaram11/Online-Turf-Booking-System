package com.onlineturfbooking.servlet;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.service.DashboardService;
import com.onlineturfbooking.service.TurfService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Mapped only to /home.
 * Never map to "/" — that replaces Tomcat's DefaultServlet and causes
 * /css and /js requests to return HTML instead of static files.
 */
@WebServlet(name = "HomeServlet", urlPatterns = "/home")
public class HomeServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(HomeServlet.class.getName());
    private final TurfService turfService = new TurfService();
    private final DashboardService dashboardService = new DashboardService();
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("featuredTurfs", turfService.listFeatured(3));
            req.setAttribute("stats", dashboardService.getAdminStats());
            req.setAttribute("recentCount", bookingService.getRecentBookings(1).size());
        } catch (AppException e) {
            LOGGER.log(Level.WARNING, "Home page data load issue", e);
            req.setAttribute("featuredTurfs", java.util.List.of());
        }
        req.getRequestDispatcher("/WEB-INF/views/public/home.jsp").forward(req, resp);
    }
}
