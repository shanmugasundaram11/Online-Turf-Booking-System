package com.onlineturfbooking.servlet;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.service.BookingService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

@WebServlet(name = "AvailabilityApiServlet", urlPatterns = "/api/availability")
public class AvailabilityApiServlet extends HttpServlet {
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        try (PrintWriter out = resp.getWriter()) {
            long turfId = Long.parseLong(req.getParameter("turfId"));
            LocalDate date = LocalDate.parse(req.getParameter("date"));
            var slots = bookingService.getAvailability(turfId, date);
            StringBuilder json = new StringBuilder("{\"slots\":[");
            for (int i = 0; i < slots.size(); i++) {
                var s = slots.get(i);
                if (i > 0) {
                    json.append(',');
                }
                json.append("{\"hour\":").append(s.getHour())
                        .append(",\"label\":\"").append(s.getLabel()).append("\"")
                        .append(",\"available\":").append(s.isAvailable()).append('}');
            }
            json.append("]}");
            out.print(json);
        } catch (AppException | RuntimeException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().print("{\"error\":\"" + escape(e.getMessage()) + "\"}");
        }
    }

    private String escape(String msg) {
        if (msg == null) {
            return "Unable to load availability";
        }
        return msg.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
