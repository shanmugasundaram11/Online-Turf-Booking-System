package com.onlineturfbooking.servlet;

import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.Turf;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.service.BookingService;
import com.onlineturfbooking.service.TurfService;
import com.onlineturfbooking.util.SessionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet(name = "TurfDetailServlet", urlPatterns = "/turfs/*")
public class TurfDetailServlet extends HttpServlet {
    private final TurfService turfService = new TurfService();
    private final BookingService bookingService = new BookingService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long turfId = extractId(req);
        if (turfId == null) {
            resp.sendRedirect(req.getContextPath() + "/turfs");
            return;
        }
        try {
            Turf turf = turfService.getActiveTurf(turfId);
            req.setAttribute("turf", turf);
            String dateParam = req.getParameter("date");
            LocalDate date = (dateParam == null || dateParam.isBlank())
                    ? LocalDate.now()
                    : LocalDate.parse(dateParam);
            if (date.isBefore(LocalDate.now())) {
                date = LocalDate.now();
            }
            req.setAttribute("selectedDate", date.toString());
            req.setAttribute("slots", bookingService.getAvailability(turfId, date));
            req.setAttribute("minDate", LocalDate.now().toString());
            req.getRequestDispatcher("/WEB-INF/views/public/turf-detail.jsp").forward(req, resp);
        } catch (AppException e) {
            SessionUtil.setFlashError(req, e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/turfs");
        } catch (Exception e) {
            SessionUtil.setFlashError(req, "Unable to load turf details.");
            resp.sendRedirect(req.getContextPath() + "/turfs");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = SessionUtil.getUser(req);
        if (user == null || !user.isCustomer()) {
            resp.sendRedirect(req.getContextPath() + "/login?redirect=" + req.getRequestURI());
            return;
        }

        Long turfId = extractId(req);
        if (turfId == null) {
            resp.sendRedirect(req.getContextPath() + "/turfs");
            return;
        }

        try {
            LocalDate date = LocalDate.parse(req.getParameter("bookingDate"));
            String hoursParam = req.getParameter("selectedHours");
            if (hoursParam == null || hoursParam.isBlank()) {
                throw new AppException("Please select at least one time slot.");
            }
            List<Integer> hours = Arrays.stream(hoursParam.split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());

            var booking = bookingService.createBooking(user.getId(), turfId, date, hours);
            SessionUtil.setFlashSuccess(req, "Booking confirmed! Reference: " + booking.getBookingCode());
            resp.sendRedirect(req.getContextPath() + "/bookings/" + booking.getId());
        } catch (AppException e) {
            SessionUtil.setFlashError(req, e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/turfs/" + turfId);
        } catch (Exception e) {
            SessionUtil.setFlashError(req, "Invalid booking request.");
            resp.sendRedirect(req.getContextPath() + "/turfs/" + turfId);
        }
    }

    private Long extractId(HttpServletRequest req) {
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            return null;
        }
        try {
            return Long.parseLong(pathInfo.substring(1).split("/")[0]);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
