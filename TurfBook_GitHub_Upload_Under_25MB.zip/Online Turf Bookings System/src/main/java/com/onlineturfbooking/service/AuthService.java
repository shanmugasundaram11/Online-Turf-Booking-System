package com.onlineturfbooking.service;

import com.onlineturfbooking.dao.UserDao;
import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.User;
import com.onlineturfbooking.model.UserRole;
import com.onlineturfbooking.model.UserStatus;
import com.onlineturfbooking.util.PasswordUtil;
import com.onlineturfbooking.util.ValidationUtil;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class AuthService {
    private final UserDao userDao = new UserDao();

    public User registerCustomer(String fullName, String email, String phone, String password, String confirmPassword)
            throws AppException {
        fullName = ValidationUtil.trim(fullName);
        email = ValidationUtil.trim(email);
        phone = ValidationUtil.trim(phone);

        if (!ValidationUtil.isValidName(fullName)) {
            throw new AppException("Please enter a valid full name (2-120 characters).");
        }
        if (!ValidationUtil.isValidEmail(email)) {
            throw new AppException("Please enter a valid email address.");
        }
        if (!ValidationUtil.isValidPhone(phone)) {
            throw new AppException("Please enter a valid 10-digit Indian mobile number.");
        }
        if (!ValidationUtil.isValidPassword(password)) {
            throw new AppException("Password must be at least 8 characters and include letters and numbers.");
        }
        if (password == null || !password.equals(confirmPassword)) {
            throw new AppException("Password and confirm password do not match.");
        }

        try {
            if (userDao.emailExists(email)) {
                throw new AppException("An account with this email already exists.");
            }

            User user = new User();
            user.setFullName(fullName);
            user.setEmail(email.toLowerCase());
            user.setPhone(phone);
            user.setPasswordHash(PasswordUtil.hash(password));
            user.setRole(UserRole.CUSTOMER);
            user.setStatus(UserStatus.ACTIVE);

            long id = userDao.create(user);
            user.setId(id);
            user.setPasswordHash(null);
            return user;
        } catch (SQLException e) {
            throw new AppException("Unable to register right now. Please try again later.", e);
        }
    }

    public User login(String email, String password, UserRole expectedRole) throws AppException {
        email = ValidationUtil.trim(email);
        if (ValidationUtil.isBlank(email) || ValidationUtil.isBlank(password)) {
            throw new AppException("Email and password are required.");
        }

        try {
            Optional<User> opt = userDao.findByEmail(email);
            if (opt.isEmpty()) {
                throw new AppException("Invalid email or password.");
            }
            User user = opt.get();
            if (!PasswordUtil.verify(password, user.getPasswordHash())) {
                throw new AppException("Invalid email or password.");
            }
            if (!user.isActive()) {
                throw new AppException("Your account has been deactivated. Please contact support.");
            }
            if (expectedRole != null && user.getRole() != expectedRole) {
                throw new AppException("Invalid email or password.");
            }
            user.setPasswordHash(null);
            return user;
        } catch (SQLException e) {
            throw new AppException("Unable to login right now. Please try again later.", e);
        }
    }

    public User getUserById(long id) throws AppException {
        try {
            return userDao.findById(id).orElseThrow(() -> new AppException("User not found."));
        } catch (SQLException e) {
            throw new AppException("Unable to load user profile.", e);
        }
    }

    public void updateProfile(long userId, String fullName, String phone) throws AppException {
        fullName = ValidationUtil.trim(fullName);
        phone = ValidationUtil.trim(phone);
        if (!ValidationUtil.isValidName(fullName)) {
            throw new AppException("Please enter a valid full name.");
        }
        if (!ValidationUtil.isValidPhone(phone)) {
            throw new AppException("Please enter a valid 10-digit mobile number.");
        }
        try {
            if (!userDao.updateProfile(userId, fullName, phone)) {
                throw new AppException("Unable to update profile.");
            }
        } catch (SQLException e) {
            throw new AppException("Unable to update profile.", e);
        }
    }

    public void changePassword(long userId, String currentPassword, String newPassword, String confirmPassword)
            throws AppException {
        if (!ValidationUtil.isValidPassword(newPassword)) {
            throw new AppException("New password must be at least 8 characters and include letters and numbers.");
        }
        if (!newPassword.equals(confirmPassword)) {
            throw new AppException("New password and confirm password do not match.");
        }
        try {
            User user = userDao.findById(userId).orElseThrow(() -> new AppException("User not found."));
            if (!PasswordUtil.verify(currentPassword, user.getPasswordHash())) {
                throw new AppException("Current password is incorrect.");
            }
            userDao.updatePassword(userId, PasswordUtil.hash(newPassword));
        } catch (SQLException e) {
            throw new AppException("Unable to change password.", e);
        }
    }

    public List<User> listCustomers(String search) throws AppException {
        try {
            return userDao.findCustomers(search);
        } catch (SQLException e) {
            throw new AppException("Unable to load customers.", e);
        }
    }

    public void setCustomerStatus(long customerId, UserStatus status) throws AppException {
        try {
            Optional<User> opt = userDao.findById(customerId);
            if (opt.isEmpty() || !opt.get().isCustomer()) {
                throw new AppException("Customer not found.");
            }
            if (!userDao.updateStatus(customerId, status)) {
                throw new AppException("Unable to update customer status.");
            }
        } catch (SQLException e) {
            throw new AppException("Unable to update customer status.", e);
        }
    }
}
