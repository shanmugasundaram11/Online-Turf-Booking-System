package com.onlineturfbooking.service;

import com.onlineturfbooking.dao.TurfDao;
import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.Booking;
import com.onlineturfbooking.model.Turf;
import com.onlineturfbooking.model.TurfStatus;
import com.onlineturfbooking.util.ValidationUtil;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

public class TurfService {
    private final TurfDao turfDao = new TurfDao();

    public List<Turf> listActiveTurfs(String search) throws AppException {
        try {
            return turfDao.findActive(search);
        } catch (SQLException e) {
            throw new AppException("Unable to load turfs.", e);
        }
    }

    public List<Turf> listFeatured(int limit) throws AppException {
        try {
            return turfDao.findFeatured(limit);
        } catch (SQLException e) {
            throw new AppException("Unable to load featured turfs.", e);
        }
    }

    public Turf getTurf(long id) throws AppException {
        try {
            return turfDao.findById(id).orElseThrow(() -> new AppException("Turf not found."));
        } catch (SQLException e) {
            throw new AppException("Unable to load turf details.", e);
        }
    }

    public Turf getActiveTurf(long id) throws AppException {
        Turf turf = getTurf(id);
        if (!turf.isActive()) {
            throw new AppException("This turf is currently unavailable.");
        }
        return turf;
    }

    public List<Turf> listAllForAdmin(String search, String status) throws AppException {
        try {
            return turfDao.findAll(search, status);
        } catch (SQLException e) {
            throw new AppException("Unable to load turfs.", e);
        }
    }

    public long createTurf(String name, String location, String description, String priceStr,
                           String openingTime, String closingTime, String amenities,
                           String imagePath, String imageColor, TurfStatus status) throws AppException {
        Turf turf = buildTurf(name, location, description, priceStr, openingTime, closingTime,
                amenities, imagePath, imageColor, status);
        try {
            return turfDao.create(turf);
        } catch (SQLException e) {
            throw new AppException("Unable to create turf.", e);
        }
    }

    public enum DeleteOutcome {
        PERMANENTLY_DELETED,
        ARCHIVED
    }

    public static class DeleteTurfResult {
        private final Turf turf;
        private final DeleteOutcome outcome;

        public DeleteTurfResult(Turf turf, DeleteOutcome outcome) {
            this.turf = turf;
            this.outcome = outcome;
        }

        public Turf getTurf() {
            return turf;
        }

        public DeleteOutcome getOutcome() {
            return outcome;
        }

        public boolean isArchived() {
            return outcome == DeleteOutcome.ARCHIVED;
        }

        public boolean isPermanentlyDeleted() {
            return outcome == DeleteOutcome.PERMANENTLY_DELETED;
        }
    }

    public void updateTurf(long id, String name, String location, String description, String priceStr,
                           String openingTime, String closingTime, String amenities,
                           String imagePath, String imageColor, TurfStatus status) throws AppException {
        Turf existing = getTurf(id); // verify exists
        if (existing.isArchived()) {
            throw new AppException("Archived turfs cannot be edited. Please restore the turf first.");
        }
        Turf turf = buildTurf(name, location, description, priceStr, openingTime, closingTime,
                amenities, imagePath, imageColor, status);
        turf.setId(id);
        try {
            if (!turfDao.update(turf)) {
                throw new AppException("Unable to update turf.");
            }
        } catch (SQLException e) {
            throw new AppException("Unable to update turf.", e);
        }
    }

    public void setStatus(long id, TurfStatus status) throws AppException {
        Turf existing = getTurf(id);
        if (existing.isArchived()) {
            throw new AppException("Cannot change status of an archived turf directly. Please restore it first.");
        }
        if (status == TurfStatus.ARCHIVED) {
            throw new AppException("Cannot set status to ARCHIVED directly. Use the delete action to archive a turf.");
        }
        try {
            if (!turfDao.updateStatus(id, status)) {
                throw new AppException("Unable to update turf status.");
            }
        } catch (SQLException e) {
            throw new AppException("Unable to update turf status.", e);
        }
    }

    public void restoreTurf(long id) throws AppException {
        Turf turf = getTurf(id);
        if (!turf.isArchived()) {
            throw new AppException("Turf '" + turf.getName() + "' is not archived.");
        }
        // Safely restore to INACTIVE so admin can inspect before activating
        try {
            if (!turfDao.updateStatus(id, TurfStatus.INACTIVE)) {
                throw new AppException("Unable to restore turf.");
            }
        } catch (SQLException e) {
            throw new AppException("Unable to restore turf.", e);
        }
    }

    public DeleteTurfResult deleteTurf(long id) throws AppException {
        Turf turf = getTurf(id);
        try {
            // 1. Block archiving or deleting if any confirmed booking is upcoming or in progress
            Optional<Booking> activeBooking = turfDao.findFirstActiveOrUpcomingBooking(id);
            if (activeBooking.isPresent()) {
                Booking b = activeBooking.get();
                throw new AppException("Cannot delete or archive turf '" + turf.getName() + "': "
                        + "It has active or upcoming confirmed bookings (Booking " + b.getBookingCode()
                        + " on " + b.getBookingDateFormatted() + " from " + b.getStartTimeFormatted()
                        + " to " + b.getEndTimeFormatted() + "). Please cancel or complete these bookings first.");
            }

            // 2. If turf has booking history (completed/cancelled), archive it to preserve history
            boolean hasHistory = turfDao.hasAssociatedRecords(id);
            if (hasHistory) {
                if (turf.isArchived()) {
                    throw new AppException("Turf '" + turf.getName() + "' is already archived to preserve booking history.");
                }
                if (!turfDao.updateStatus(id, TurfStatus.ARCHIVED)) {
                    throw new AppException("Unable to archive turf.");
                }
                turf.setStatus(TurfStatus.ARCHIVED);
                return new DeleteTurfResult(turf, DeleteOutcome.ARCHIVED);
            }

            // 3. No booking history at all: permanently delete
            if (!turfDao.delete(id)) {
                throw new AppException("Unable to delete turf.");
            }
            return new DeleteTurfResult(turf, DeleteOutcome.PERMANENTLY_DELETED);
        } catch (SQLException e) {
            if (e.getErrorCode() == 1451 || "23000".equals(e.getSQLState())) {
                throw new AppException("Cannot permanently delete turf '" + turf.getName()
                        + "': It has existing booking records. The turf has been protected to preserve booking history.");
            }
            throw new AppException("Unable to delete turf due to a database error.", e);
        }
    }

    public boolean isImagePathShared(String imagePath, long excludeTurfId) throws AppException {
        try {
            return turfDao.isImagePathShared(imagePath, excludeTurfId);
        } catch (SQLException e) {
            return true;
        }
    }

    private Turf buildTurf(String name, String location, String description, String priceStr,
                           String openingTime, String closingTime, String amenities,
                           String imagePath, String imageColor, TurfStatus status) throws AppException {
        name = ValidationUtil.trim(name);
        location = ValidationUtil.trim(location);
        description = ValidationUtil.trim(description);
        amenities = ValidationUtil.trim(amenities);
        imageColor = ValidationUtil.trim(imageColor);

        if (ValidationUtil.isBlank(name) || name.length() < 2) {
            throw new AppException("Turf name is required.");
        }
        if (ValidationUtil.isBlank(location)) {
            throw new AppException("Location is required.");
        }
        if (ValidationUtil.isBlank(description) || description.length() < 10) {
            throw new AppException("Please provide a meaningful description.");
        }
        if (ValidationUtil.isBlank(amenities)) {
            throw new AppException("Please list at least one amenity.");
        }

        BigDecimal price;
        try {
            price = new BigDecimal(priceStr.trim());
            if (price.compareTo(BigDecimal.ZERO) <= 0) {
                throw new AppException("Price per hour must be greater than zero.");
            }
        } catch (NumberFormatException e) {
            throw new AppException("Invalid price per hour.");
        }

        LocalTime open;
        LocalTime close;
        try {
            open = LocalTime.parse(normalizeTime(openingTime));
            close = LocalTime.parse(normalizeTime(closingTime));
        } catch (DateTimeParseException e) {
            throw new AppException("Invalid opening or closing time.");
        }
        if (!close.isAfter(open)) {
            throw new AppException("Closing time must be after opening time.");
        }
        if (open.getMinute() != 0 || close.getMinute() != 0) {
            throw new AppException("Operating hours must be on the hour (e.g. 06:00, 22:00).");
        }

        if (imageColor == null || !imageColor.matches("^#[0-9A-Fa-f]{6}$")) {
            imageColor = "#1a5c3a";
        }
        if (status == null) {
            status = TurfStatus.ACTIVE;
        } else if (status == TurfStatus.ARCHIVED) {
            throw new AppException("Turf cannot be created or updated with ARCHIVED status directly.");
        }

        // Normalize imagePath: blank/whitespace-only becomes null
        String cleanImagePath = (imagePath != null && !imagePath.isBlank()) ? imagePath.trim() : null;

        Turf turf = new Turf();
        turf.setName(name);
        turf.setLocation(location);
        turf.setDescription(description);
        turf.setPricePerHour(price);
        turf.setOpeningTime(open);
        turf.setClosingTime(close);
        turf.setAmenities(amenities);
        turf.setImagePath(cleanImagePath);
        turf.setImageColor(imageColor);
        turf.setStatus(status);
        return turf;
    }

    private String normalizeTime(String time) {
        if (time == null) {
            return "";
        }
        time = time.trim();
        if (time.length() == 5) {
            return time + ":00";
        }
        return time;
    }
}
