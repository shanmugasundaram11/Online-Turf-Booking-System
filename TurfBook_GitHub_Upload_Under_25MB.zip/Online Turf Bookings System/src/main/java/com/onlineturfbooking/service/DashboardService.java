package com.onlineturfbooking.service;

import com.onlineturfbooking.dao.BookingDao;
import com.onlineturfbooking.dao.TurfDao;
import com.onlineturfbooking.dao.UserDao;
import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.BookingStatus;
import com.onlineturfbooking.model.DashboardStats;
import com.onlineturfbooking.model.TurfStatus;
import com.onlineturfbooking.model.UserRole;
import com.onlineturfbooking.model.UserStatus;

import java.sql.SQLException;

public class DashboardService {
    private final BookingDao bookingDao = new BookingDao();
    private final TurfDao turfDao = new TurfDao();
    private final UserDao userDao = new UserDao();

    public DashboardStats getAdminStats() throws AppException {
        try {
            DashboardStats stats = new DashboardStats();
            stats.setTotalTurfs(turfDao.countAll());
            stats.setActiveTurfs(turfDao.countByStatus(TurfStatus.ACTIVE));
            stats.setTotalBookings(bookingDao.countAll());
            stats.setConfirmedBookings(bookingDao.countByStatus(BookingStatus.CONFIRMED));
            stats.setCancelledBookings(bookingDao.countByStatus(BookingStatus.CANCELLED));
            stats.setCompletedBookings(bookingDao.countByStatus(BookingStatus.COMPLETED));
            stats.setTotalCustomers(userDao.countByRole(UserRole.CUSTOMER));
            stats.setActiveCustomers(userDao.countByRoleAndStatus(UserRole.CUSTOMER, UserStatus.ACTIVE));
            return stats;
        } catch (SQLException e) {
            throw new AppException("Unable to load dashboard statistics.", e);
        }
    }

    public DashboardStats getCustomerStats(long customerId) throws AppException {
        try {
            DashboardStats stats = new DashboardStats();
            stats.setUserTotalBookings(bookingDao.countByCustomer(customerId));
            stats.setUserActiveBookings(bookingDao.countActiveByCustomer(customerId));
            stats.setActiveTurfs(turfDao.countByStatus(TurfStatus.ACTIVE));
            return stats;
        } catch (SQLException e) {
            throw new AppException("Unable to load dashboard statistics.", e);
        }
    }
}
