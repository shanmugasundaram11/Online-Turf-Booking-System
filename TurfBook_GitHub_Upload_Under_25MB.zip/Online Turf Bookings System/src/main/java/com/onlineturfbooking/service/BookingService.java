package com.onlineturfbooking.service;

import com.onlineturfbooking.dao.BookingDao;
import com.onlineturfbooking.dao.TurfDao;
import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.Booking;
import com.onlineturfbooking.model.BookingStatus;
import com.onlineturfbooking.model.TimeSlot;
import com.onlineturfbooking.model.Turf;
import com.onlineturfbooking.util.BookingCodeGenerator;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class BookingService {
    private final BookingDao bookingDao = new BookingDao();
    private final TurfDao turfDao = new TurfDao();

    public List<TimeSlot> getAvailability(long turfId, LocalDate date) throws AppException {
        if (date == null || date.isBefore(LocalDate.now())) {
            throw new AppException("Please select today or a future date.");
        }
        try {
            Turf turf = turfDao.findById(turfId)
                    .orElseThrow(() -> new AppException("Turf not found."));
            if (!turf.isActive()) {
                throw new AppException("This turf is currently unavailable.");
            }

            Set<Integer> booked = bookingDao.findBookedHours(turfId, date);
            int openHour = turf.getOpeningTime().getHour();
            int closeHour = turf.getClosingTime().getHour();

            List<TimeSlot> slots = new ArrayList<>();
            LocalDateTime now = LocalDateTime.now();
            for (int hour = openHour; hour < closeHour; hour++) {
                boolean available = !booked.contains(hour);
                if (date.equals(LocalDate.now())) {
                    LocalDateTime slotStart = LocalDateTime.of(date, LocalTime.of(hour, 0));
                    if (!slotStart.isAfter(now)) {
                        available = false;
                    }
                }
                slots.add(new TimeSlot(hour, available));
            }
            return slots;
        } catch (SQLException e) {
            throw new AppException("Unable to load availability.", e);
        }
    }

    public Booking createBooking(long customerId, long turfId, LocalDate date, List<Integer> selectedHours)
            throws AppException {
        if (selectedHours == null || selectedHours.isEmpty()) {
            throw new AppException("Please select at least one time slot.");
        }

        List<Integer> hours = selectedHours.stream().distinct().sorted().collect(Collectors.toList());
        validateConsecutive(hours);

        if (date == null || date.isBefore(LocalDate.now())) {
            throw new AppException("Booking date cannot be in the past.");
        }

        try {
            Turf turf = turfDao.findById(turfId)
                    .orElseThrow(() -> new AppException("Invalid turf selected."));
            if (!turf.isActive()) {
                throw new AppException("This turf is currently unavailable for booking.");
            }

            int openHour = turf.getOpeningTime().getHour();
            int closeHour = turf.getClosingTime().getHour();
            for (Integer hour : hours) {
                if (hour < openHour || hour >= closeHour) {
                    throw new AppException("Selected slots are outside turf operating hours.");
                }
            }

            LocalTime startTime = LocalTime.of(hours.get(0), 0);
            LocalTime endTime = LocalTime.of(hours.get(hours.size() - 1) + 1, 0);

            if (date.equals(LocalDate.now()) && !LocalDateTime.of(date, startTime).isAfter(LocalDateTime.now())) {
                throw new AppException("Cannot book a time slot that has already started.");
            }

            BigDecimal duration = BigDecimal.valueOf(hours.size());
            BigDecimal total = turf.getPricePerHour().multiply(duration);

            Booking booking = new Booking();
            booking.setBookingCode(BookingCodeGenerator.generate());
            booking.setCustomerId(customerId);
            booking.setTurfId(turfId);
            booking.setBookingDate(date);
            booking.setStartTime(startTime);
            booking.setEndTime(endTime);
            booking.setDurationHours(duration);
            booking.setPricePerHour(turf.getPricePerHour());
            booking.setTotalAmount(total);
            booking.setStatus(BookingStatus.CONFIRMED);

            long id = bookingDao.createBookingAtomic(booking, hours);
            return bookingDao.findById(id)
                    .orElseThrow(() -> new AppException("Booking created but could not be loaded."));
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("SLOT_CONFLICT")) {
                throw new AppException("One or more selected slots were just booked by someone else. Please choose different times.");
            }
            if (e.getMessage() != null && (e.getMessage().contains("Duplicate") || e.getErrorCode() == 1062)) {
                throw new AppException("One or more selected slots are no longer available. Please refresh and try again.");
            }
            throw new AppException("Unable to complete booking. Please try again.", e);
        }
    }

    public List<Booking> getCustomerBookings(long customerId) throws AppException {
        try {
            return bookingDao.findByCustomer(customerId);
        } catch (SQLException e) {
            throw new AppException("Unable to load bookings.", e);
        }
    }

    public Booking getBookingForCustomer(long bookingId, long customerId) throws AppException {
        try {
            Booking booking = bookingDao.findById(bookingId)
                    .orElseThrow(() -> new AppException("Booking not found."));
            if (booking.getCustomerId() != customerId) {
                throw new AppException("You are not authorized to view this booking.");
            }
            return booking;
        } catch (SQLException e) {
            throw new AppException("Unable to load booking details.", e);
        }
    }

    public Booking getBooking(long bookingId) throws AppException {
        try {
            return bookingDao.findById(bookingId)
                    .orElseThrow(() -> new AppException("Booking not found."));
        } catch (SQLException e) {
            throw new AppException("Unable to load booking details.", e);
        }
    }

    public void cancelBooking(long bookingId, long customerId) throws AppException {
        try {
            Booking booking = bookingDao.findById(bookingId)
                    .orElseThrow(() -> new AppException("Booking not found."));
            if (booking.getCustomerId() != customerId) {
                throw new AppException("You are not authorized to cancel this booking.");
            }
            if (booking.getStatus() != BookingStatus.CONFIRMED) {
                throw new AppException("Only confirmed bookings can be cancelled.");
            }
            if (!booking.isCancellable()) {
                throw new AppException("Bookings can only be cancelled at least 2 hours before start time.");
            }
            if (!bookingDao.cancelForCustomer(bookingId, customerId)) {
                throw new AppException("Unable to cancel booking.");
            }
        } catch (SQLException e) {
            throw new AppException("Unable to cancel booking.", e);
        }
    }

    /**
     * Admin-only status update. Enforces the following allowed transitions:
     * <ul>
     *   <li>CONFIRMED  → CANCELLED  (releases slots)</li>
     *   <li>CONFIRMED  → COMPLETED  (only after booking end time; releases slots)</li>
     * </ul>
     * All other transitions are rejected.
     */
    public void updateStatus(long bookingId, BookingStatus newStatus) throws AppException {
        if (newStatus == null) {
            throw new AppException("Invalid booking status.");
        }
        try {
            Booking booking = bookingDao.findById(bookingId)
                    .orElseThrow(() -> new AppException("Booking not found."));

            BookingStatus current = booking.getStatus();
            if (current == newStatus) {
                // No-op — already in target state.
                return;
            }

            // ---- Transition validation ----
            if (current == BookingStatus.CANCELLED) {
                throw new AppException(
                        "Cancelled bookings cannot be changed. A cancelled booking is final.");
            }
            if (current == BookingStatus.COMPLETED) {
                throw new AppException(
                        "Completed bookings cannot be changed. A completed booking is final.");
            }
            // current must be CONFIRMED from here on
            if (newStatus == BookingStatus.CONFIRMED) {
                // CONFIRMED → CONFIRMED is already caught by the equality check above.
                // Any attempt to move *to* CONFIRMED from a non-CONFIRMED state is blocked above.
                // Reaching here would mean current == CONFIRMED && newStatus == CONFIRMED,
                // which is impossible (caught by equality check). Guard for safety:
                throw new AppException("Status is already CONFIRMED.");
            }
            if (newStatus == BookingStatus.COMPLETED) {
                // Only allow COMPLETED if the booking's end date/time has passed.
                if (booking.getBookingDate() == null || booking.getEndTime() == null) {
                    throw new AppException(
                            "Cannot mark booking as completed: booking date/time is missing.");
                }
                LocalDateTime endDateTime = LocalDateTime.of(
                        booking.getBookingDate(), booking.getEndTime());
                if (LocalDateTime.now().isBefore(endDateTime)) {
                    throw new AppException(
                            "Cannot mark booking as completed before its end time (" +
                            booking.getEndTimeFormatted() + " on " +
                            booking.getBookingDateFormatted() + ").");
                }
            }
            // newStatus is CANCELLED or (COMPLETED after end time) — both are valid

            if (!bookingDao.updateStatus(bookingId, newStatus)) {
                throw new AppException("Unable to update booking status.");
            }
        } catch (SQLException e) {
            throw new AppException("Unable to update booking status.", e);
        }
    }

    public List<Booking> searchBookings(String search, String status, LocalDate from, LocalDate to)
            throws AppException {
        try {
            return bookingDao.search(search, status, from, to);
        } catch (SQLException e) {
            throw new AppException("Unable to search bookings.", e);
        }
    }

    public List<Booking> getRecentBookings(int limit) throws AppException {
        try {
            return bookingDao.findRecent(limit);
        } catch (SQLException e) {
            throw new AppException("Unable to load recent bookings.", e);
        }
    }

    public List<Booking> getUpcomingForCustomer(long customerId, int limit) throws AppException {
        try {
            return bookingDao.findUpcomingByCustomer(customerId, limit);
        } catch (SQLException e) {
            throw new AppException("Unable to load upcoming bookings.", e);
        }
    }

    private void validateConsecutive(List<Integer> hours) throws AppException {
        if (hours.isEmpty()) {
            throw new AppException("Please select at least one time slot.");
        }
        List<Integer> sorted = new ArrayList<>(hours);
        Collections.sort(sorted);
        for (int i = 1; i < sorted.size(); i++) {
            if (sorted.get(i) != sorted.get(i - 1) + 1) {
                throw new AppException("Please select consecutive hourly slots only.");
            }
        }
    }
}
