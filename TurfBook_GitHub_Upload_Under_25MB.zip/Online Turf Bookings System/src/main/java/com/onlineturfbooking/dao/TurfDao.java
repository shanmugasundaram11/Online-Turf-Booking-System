package com.onlineturfbooking.dao;

import com.onlineturfbooking.model.Booking;
import com.onlineturfbooking.model.BookingStatus;
import com.onlineturfbooking.model.Turf;
import com.onlineturfbooking.model.TurfStatus;
import com.onlineturfbooking.util.DBConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TurfDao {

    public Optional<Turf> findById(long id) throws SQLException {
        String sql = "SELECT * FROM turfs WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(map(rs));
                }
            }
        }
        return Optional.empty();
    }

    public List<Turf> findActive(String search) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM turfs WHERE status = 'ACTIVE'");
        List<Object> params = new ArrayList<>();
        if (search != null && !search.isBlank()) {
            sql.append(" AND (name LIKE ? OR location LIKE ? OR amenities LIKE ?)");
            String like = "%" + search.trim() + "%";
            params.add(like);
            params.add(like);
            params.add(like);
        }
        sql.append(" ORDER BY name ASC");
        return queryList(sql.toString(), params);
    }

    public List<Turf> findFeatured(int limit) throws SQLException {
        String sql = "SELECT * FROM turfs WHERE status = 'ACTIVE' ORDER BY id ASC LIMIT ?";
        List<Turf> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public List<Turf> findAll(String search, String statusFilter) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM turfs WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (search != null && !search.isBlank()) {
            sql.append(" AND (name LIKE ? OR location LIKE ?)");
            String like = "%" + search.trim() + "%";
            params.add(like);
            params.add(like);
        }
        if (statusFilter != null && !statusFilter.isBlank() && !"ALL".equalsIgnoreCase(statusFilter)) {
            sql.append(" AND status = ?");
            params.add(statusFilter.toUpperCase());
        }
        sql.append(" ORDER BY updated_at DESC");
        return queryList(sql.toString(), params);
    }

    public long create(Turf turf) throws SQLException {
        String sql = """
                INSERT INTO turfs (name, location, description, price_per_hour, opening_time, closing_time,
                amenities, image_path, image_color, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bindTurf(ps, turf);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getLong(1);
                }
            }
        }
        throw new SQLException("Failed to create turf");
    }

    public boolean update(Turf turf) throws SQLException {
        String sql = """
                UPDATE turfs SET name=?, location=?, description=?, price_per_hour=?, opening_time=?,
                closing_time=?, amenities=?, image_path=?, image_color=?, status=? WHERE id=?
                """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            bindTurf(ps, turf);
            ps.setLong(11, turf.getId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateStatus(long id, TurfStatus status) throws SQLException {
        String sql = "UPDATE turfs SET status = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setLong(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean hasAssociatedRecords(long turfId) throws SQLException {
        String sql = "SELECT 1 FROM bookings WHERE turf_id = ? UNION SELECT 1 FROM booking_slots WHERE turf_id = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, turfId);
            ps.setLong(2, turfId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public Optional<Booking> findFirstActiveOrUpcomingBooking(long turfId) throws SQLException {
        String sql = """
                SELECT id, booking_code, booking_date, start_time, end_time, status
                FROM bookings
                WHERE turf_id = ?
                  AND status = 'CONFIRMED'
                  AND (booking_date > ? OR (booking_date = ? AND end_time > ?))
                ORDER BY booking_date ASC, start_time ASC
                LIMIT 1
                """;
        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, turfId);
            ps.setDate(2, Date.valueOf(today));
            ps.setDate(3, Date.valueOf(today));
            ps.setTime(4, Time.valueOf(now));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Booking b = new Booking();
                    b.setId(rs.getLong("id"));
                    b.setBookingCode(rs.getString("booking_code"));
                    Date d = rs.getDate("booking_date");
                    if (d != null) {
                        b.setBookingDate(d.toLocalDate());
                    }
                    Time st = rs.getTime("start_time");
                    if (st != null) {
                        b.setStartTime(st.toLocalTime());
                    }
                    Time et = rs.getTime("end_time");
                    if (et != null) {
                        b.setEndTime(et.toLocalTime());
                    }
                    b.setStatus(BookingStatus.valueOf(rs.getString("status")));
                    return Optional.of(b);
                }
            }
        }
        return Optional.empty();
    }

    public boolean delete(long id) throws SQLException {
        String sql = "DELETE FROM turfs WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean isImagePathShared(String imagePath, long excludeTurfId) throws SQLException {
        if (imagePath == null || imagePath.isBlank()) {
            return false;
        }
        String sql = "SELECT 1 FROM turfs WHERE image_path = ? AND id != ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, imagePath.trim());
            ps.setLong(2, excludeTurfId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public long countAll() throws SQLException {
        return count("SELECT COUNT(*) FROM turfs");
    }

    public long countByStatus(TurfStatus status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM turfs WHERE status = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        }
    }

    private long count(String sql) throws SQLException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getLong(1) : 0;
        }
    }

    private void bindTurf(PreparedStatement ps, Turf turf) throws SQLException {
        ps.setString(1, turf.getName());
        ps.setString(2, turf.getLocation());
        ps.setString(3, turf.getDescription());
        ps.setBigDecimal(4, turf.getPricePerHour());
        ps.setTime(5, Time.valueOf(turf.getOpeningTime()));
        ps.setTime(6, Time.valueOf(turf.getClosingTime()));
        ps.setString(7, turf.getAmenities());
        ps.setString(8, turf.getImagePath());
        ps.setString(9, turf.getImageColor());
        ps.setString(10, turf.getStatus().name());
    }

    private List<Turf> queryList(String sql, List<Object> params) throws SQLException {
        List<Turf> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    private Turf map(ResultSet rs) throws SQLException {
        Turf turf = new Turf();
        turf.setId(rs.getLong("id"));
        turf.setName(rs.getString("name"));
        turf.setLocation(rs.getString("location"));
        turf.setDescription(rs.getString("description"));
        turf.setPricePerHour(rs.getBigDecimal("price_per_hour"));
        Time open = rs.getTime("opening_time");
        Time close = rs.getTime("closing_time");
        if (open != null) {
            turf.setOpeningTime(open.toLocalTime());
        }
        if (close != null) {
            turf.setClosingTime(close.toLocalTime());
        }
        turf.setAmenities(rs.getString("amenities"));
        turf.setImagePath(rs.getString("image_path"));
        turf.setImageColor(rs.getString("image_color"));
        turf.setStatus(TurfStatus.valueOf(rs.getString("status")));
        Timestamp created = rs.getTimestamp("created_at");
        Timestamp updated = rs.getTimestamp("updated_at");
        if (created != null) {
            turf.setCreatedAt(created.toLocalDateTime());
        }
        if (updated != null) {
            turf.setUpdatedAt(updated.toLocalDateTime());
        }
        return turf;
    }
}
