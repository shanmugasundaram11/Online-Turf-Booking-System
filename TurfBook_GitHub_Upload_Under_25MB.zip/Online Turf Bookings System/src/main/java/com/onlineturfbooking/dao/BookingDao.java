package com.onlineturfbooking.dao;

import com.onlineturfbooking.model.Booking;
import com.onlineturfbooking.model.BookingStatus;
import com.onlineturfbooking.util.DBConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class BookingDao {

    private static final String SELECT_WITH_JOINS = """
            SELECT b.*, u.full_name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
                   t.name AS turf_name, t.location AS turf_location
            FROM bookings b
            JOIN users u ON u.id = b.customer_id
            JOIN turfs t ON t.id = b.turf_id
            """;

    public Set<Integer> findBookedHours(long turfId, LocalDate date) throws SQLException {
        String sql = """
                SELECT slot_hour FROM booking_slots
                WHERE turf_id = ? AND slot_date = ?
                """;
        Set<Integer> hours = new HashSet<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, turfId);
            ps.setDate(2, Date.valueOf(date));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    hours.add(rs.getInt("slot_hour"));
                }
            }
        }
        return hours;
    }

    /**
     * Atomically creates a booking and all covered hourly slots.
     * Uses a transaction with unique constraint on (turf_id, slot_date, slot_hour)
     * to prevent double booking under concurrency.
     */
    public long createBookingAtomic(Booking booking, List<Integer> hours) throws SQLException {
        String insertBooking = """
                INSERT INTO bookings (booking_code, customer_id, turf_id, booking_date, start_time, end_time,
                duration_hours, price_per_hour, total_amount, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;
        String insertSlot = """
                INSERT INTO booking_slots (booking_id, turf_id, slot_date, slot_hour)
                VALUES (?, ?, ?, ?)
                """;

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            // Serialize bookings for this turf by locking the turf row
            String turfLockSql = "SELECT id FROM turfs WHERE id = ? FOR UPDATE";
            try (PreparedStatement turfLock = conn.prepareStatement(turfLockSql)) {
                turfLock.setLong(1, booking.getTurfId());
                try (ResultSet rs = turfLock.executeQuery()) {
                    if (!rs.next()) {
                        throw new SQLException("Turf not found");
                    }
                }
            }

            String lockSql = "SELECT slot_hour FROM booking_slots WHERE turf_id = ? AND slot_date = ? FOR UPDATE";
            try (PreparedStatement lockPs = conn.prepareStatement(lockSql)) {
                lockPs.setLong(1, booking.getTurfId());
                lockPs.setDate(2, Date.valueOf(booking.getBookingDate()));
                try (ResultSet rs = lockPs.executeQuery()) {
                    Set<Integer> occupied = new HashSet<>();
                    while (rs.next()) {
                        occupied.add(rs.getInt("slot_hour"));
                    }
                    for (Integer hour : hours) {
                        if (occupied.contains(hour)) {
                            throw new SQLException("SLOT_CONFLICT:" + hour);
                        }
                    }
                }
            }

            long bookingId;
            try (PreparedStatement ps = conn.prepareStatement(insertBooking, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, booking.getBookingCode());
                ps.setLong(2, booking.getCustomerId());
                ps.setLong(3, booking.getTurfId());
                ps.setDate(4, Date.valueOf(booking.getBookingDate()));
                ps.setTime(5, Time.valueOf(booking.getStartTime()));
                ps.setTime(6, Time.valueOf(booking.getEndTime()));
                ps.setBigDecimal(7, booking.getDurationHours());
                ps.setBigDecimal(8, booking.getPricePerHour());
                ps.setBigDecimal(9, booking.getTotalAmount());
                ps.setString(10, booking.getStatus().name());
                ps.setString(11, booking.getNotes());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (!keys.next()) {
                        throw new SQLException("Failed to create booking record");
                    }
                    bookingId = keys.getLong(1);
                }
            }

            try (PreparedStatement slotPs = conn.prepareStatement(insertSlot)) {
                for (Integer hour : hours) {
                    slotPs.setLong(1, bookingId);
                    slotPs.setLong(2, booking.getTurfId());
                    slotPs.setDate(3, Date.valueOf(booking.getBookingDate()));
                    slotPs.setInt(4, hour);
                    slotPs.addBatch();
                }
                slotPs.executeBatch();
            }

            conn.commit();
            return bookingId;
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackEx) {
                    e.addSuppressed(rollbackEx);
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {
                    // ignore
                }
            }
        }
    }

    public Optional<Booking> findById(long id) throws SQLException {
        String sql = SELECT_WITH_JOINS + " WHERE b.id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(map(rs));
                }
            }
        }
        return Optional.empty();
    }

    public List<Booking> findByCustomer(long customerId) throws SQLException {
        String sql = SELECT_WITH_JOINS + " WHERE b.customer_id = ? ORDER BY b.booking_date DESC, b.start_time DESC";
        return queryList(sql, List.of(customerId));
    }

    public List<Booking> findUpcomingByCustomer(long customerId, int limit) throws SQLException {
        String sql = SELECT_WITH_JOINS + """
                 WHERE b.customer_id = ? AND b.status = 'CONFIRMED'
                 AND (b.booking_date > CURDATE() OR (b.booking_date = CURDATE() AND b.start_time >= CURTIME()))
                 ORDER BY b.booking_date ASC, b.start_time ASC LIMIT ?
                """;
        return queryList(sql, List.of(customerId, limit));
    }

    public List<Booking> findRecent(int limit) throws SQLException {
        String sql = SELECT_WITH_JOINS + " ORDER BY b.created_at DESC LIMIT ?";
        return queryList(sql, List.of(limit));
    }

    public List<Booking> search(String search, String status, LocalDate fromDate, LocalDate toDate) throws SQLException {
        StringBuilder sql = new StringBuilder(SELECT_WITH_JOINS + " WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (search != null && !search.isBlank()) {
            sql.append(" AND (b.booking_code LIKE ? OR u.full_name LIKE ? OR u.email LIKE ? OR t.name LIKE ?)");
            String like = "%" + search.trim() + "%";
            params.add(like);
            params.add(like);
            params.add(like);
            params.add(like);
        }
        if (status != null && !status.isBlank() && !"ALL".equalsIgnoreCase(status)) {
            sql.append(" AND b.status = ?");
            params.add(status.toUpperCase());
        }
        if (fromDate != null) {
            sql.append(" AND b.booking_date >= ?");
            params.add(Date.valueOf(fromDate));
        }
        if (toDate != null) {
            sql.append(" AND b.booking_date <= ?");
            params.add(Date.valueOf(toDate));
        }
        sql.append(" ORDER BY b.booking_date DESC, b.start_time DESC");
        return queryList(sql.toString(), params);
    }

    public boolean updateStatus(long bookingId, BookingStatus status) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            String updateSql = "UPDATE bookings SET status = ? WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setString(1, status.name());
                ps.setLong(2, bookingId);
                if (ps.executeUpdate() == 0) {
                    conn.rollback();
                    return false;
                }
            }

            // Release occupied slots for both CANCELLED and COMPLETED.
            // CANCELLED: slots become bookable again immediately.
            // COMPLETED: the session is over; holding the rows serves no purpose
            //            and could cause availability inconsistencies.
            if (status == BookingStatus.CANCELLED || status == BookingStatus.COMPLETED) {
                String deleteSlots = "DELETE FROM booking_slots WHERE booking_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(deleteSlots)) {
                    ps.setLong(1, bookingId);
                    ps.executeUpdate();
                }
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackEx) {
                    e.addSuppressed(rollbackEx);
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {
                    // ignore
                }
            }
        }
    }

    public boolean cancelForCustomer(long bookingId, long customerId) throws SQLException {
        Optional<Booking> opt = findById(bookingId);
        if (opt.isEmpty()) {
            return false;
        }
        Booking booking = opt.get();
        if (booking.getCustomerId() != customerId) {
            return false;
        }
        if (booking.getStatus() != BookingStatus.CONFIRMED) {
            return false;
        }
        if (!booking.isCancellable()) {
            return false;
        }
        return updateStatus(bookingId, BookingStatus.CANCELLED);
    }

    public long countAll() throws SQLException {
        return scalar("SELECT COUNT(*) FROM bookings");
    }

    public long countByStatus(BookingStatus status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM bookings WHERE status = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        }
    }

    public long countByCustomer(long customerId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM bookings WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        }
    }

    public long countActiveByCustomer(long customerId) throws SQLException {
        String sql = """
                SELECT COUNT(*) FROM bookings WHERE customer_id = ? AND status = 'CONFIRMED'
                AND (booking_date > CURDATE() OR (booking_date = CURDATE() AND start_time >= CURTIME()))
                """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        }
    }

    private long scalar(String sql) throws SQLException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getLong(1) : 0;
        }
    }

    private List<Booking> queryList(String sql, List<?> params) throws SQLException {
        List<Booking> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.size(); i++) {
                Object p = params.get(i);
                if (p instanceof Date || p instanceof Integer || p instanceof Long || p instanceof String
                        || p instanceof BigDecimal) {
                    ps.setObject(i + 1, p);
                } else {
                    ps.setObject(i + 1, p);
                }
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    private Booking map(ResultSet rs) throws SQLException {
        Booking b = new Booking();
        b.setId(rs.getLong("id"));
        b.setBookingCode(rs.getString("booking_code"));
        b.setCustomerId(rs.getLong("customer_id"));
        b.setTurfId(rs.getLong("turf_id"));
        Date d = rs.getDate("booking_date");
        if (d != null) {
            b.setBookingDate(d.toLocalDate());
        }
        Time start = rs.getTime("start_time");
        Time end = rs.getTime("end_time");
        if (start != null) {
            b.setStartTime(start.toLocalTime());
        }
        if (end != null) {
            b.setEndTime(end.toLocalTime());
        }
        b.setDurationHours(rs.getBigDecimal("duration_hours"));
        b.setPricePerHour(rs.getBigDecimal("price_per_hour"));
        b.setTotalAmount(rs.getBigDecimal("total_amount"));
        b.setStatus(BookingStatus.valueOf(rs.getString("status")));
        b.setNotes(rs.getString("notes"));
        Timestamp created = rs.getTimestamp("created_at");
        Timestamp updated = rs.getTimestamp("updated_at");
        if (created != null) {
            b.setCreatedAt(created.toLocalDateTime());
        }
        if (updated != null) {
            b.setUpdatedAt(updated.toLocalDateTime());
        }
        try {
            b.setCustomerName(rs.getString("customer_name"));
            b.setCustomerEmail(rs.getString("customer_email"));
            b.setCustomerPhone(rs.getString("customer_phone"));
            b.setTurfName(rs.getString("turf_name"));
            b.setTurfLocation(rs.getString("turf_location"));
        } catch (SQLException ignored) {
            // optional joined columns
        }
        return b;
    }
}
