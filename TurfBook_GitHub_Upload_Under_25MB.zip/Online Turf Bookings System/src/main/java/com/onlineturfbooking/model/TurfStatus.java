package com.onlineturfbooking.model;

public enum TurfStatus {
    ACTIVE,
    INACTIVE,
    ARCHIVED
}
