package com.onlineturfbooking.model;

public enum UserStatus {
    ACTIVE,
    INACTIVE
}
