package com.onlineturfbooking.model;

/**
 * Represents a single hourly availability slot for display and selection.
 */
public class TimeSlot {
    private int hour;
    private String label;
    private boolean available;
    private boolean selected;

    public TimeSlot() {
    }

    public TimeSlot(int hour, boolean available) {
        this.hour = hour;
        this.available = available;
        this.label = String.format("%02d:00 - %02d:00", hour, hour + 1);
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getStartLabel() {
        return String.format("%02d:00", hour);
    }
}
