package com.onlineturfbooking.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Turf {
    private long id;
    private String name;
    private String location;
    private String description;
    private BigDecimal pricePerHour;
    private LocalTime openingTime;
    private LocalTime closingTime;
    private String amenities;
    private String imagePath;
    private String imageColor;
    private TurfStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public Turf() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPricePerHour() {
        return pricePerHour;
    }

    public void setPricePerHour(BigDecimal pricePerHour) {
        this.pricePerHour = pricePerHour;
    }

    public LocalTime getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(LocalTime openingTime) {
        this.openingTime = openingTime;
    }

    public String getOpeningTimeFormatted() {
        return openingTime != null ? openingTime.toString().substring(0, 5) : "";
    }

    public LocalTime getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(LocalTime closingTime) {
        this.closingTime = closingTime;
    }

    public String getClosingTimeFormatted() {
        return closingTime != null ? closingTime.toString().substring(0, 5) : "";
    }

    public String getAmenities() {
        return amenities;
    }

    public void setAmenities(String amenities) {
        this.amenities = amenities;
    }

    public List<String> getAmenityList() {
        if (amenities == null || amenities.isBlank()) {
            return Collections.emptyList();
        }
        return Arrays.stream(amenities.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getImageColor() {
        return imageColor != null ? imageColor : "#1a5c3a";
    }

    public void setImageColor(String imageColor) {
        this.imageColor = imageColor;
    }

    public TurfStatus getStatus() {
        return status;
    }

    public void setStatus(TurfStatus status) {
        this.status = status;
    }

    public boolean isActive() {
        return status == TurfStatus.ACTIVE;
    }

    public boolean isArchived() {
        return status == TurfStatus.ARCHIVED;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getShortDescription() {
        if (description == null) {
            return "";
        }
        return description.length() <= 120 ? description : description.substring(0, 117) + "...";
    }
}
