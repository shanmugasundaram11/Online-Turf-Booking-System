package com.onlineturfbooking.model;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    COMPLETED
}
