package com.onlineturfbooking.model;

/**
 * Aggregated statistics for admin and customer dashboards.
 */
public class DashboardStats {
    private long totalTurfs;
    private long activeTurfs;
    private long totalBookings;
    private long confirmedBookings;
    private long cancelledBookings;
    private long completedBookings;
    private long totalCustomers;
    private long activeCustomers;
    private long upcomingBookings;
    private long userTotalBookings;
    private long userActiveBookings;

    public long getTotalTurfs() {
        return totalTurfs;
    }

    public void setTotalTurfs(long totalTurfs) {
        this.totalTurfs = totalTurfs;
    }

    public long getActiveTurfs() {
        return activeTurfs;
    }

    public void setActiveTurfs(long activeTurfs) {
        this.activeTurfs = activeTurfs;
    }

    public long getTotalBookings() {
        return totalBookings;
    }

    public void setTotalBookings(long totalBookings) {
        this.totalBookings = totalBookings;
    }

    public long getConfirmedBookings() {
        return confirmedBookings;
    }

    public void setConfirmedBookings(long confirmedBookings) {
        this.confirmedBookings = confirmedBookings;
    }

    public long getCancelledBookings() {
        return cancelledBookings;
    }

    public void setCancelledBookings(long cancelledBookings) {
        this.cancelledBookings = cancelledBookings;
    }

    public long getCompletedBookings() {
        return completedBookings;
    }

    public void setCompletedBookings(long completedBookings) {
        this.completedBookings = completedBookings;
    }

    public long getTotalCustomers() {
        return totalCustomers;
    }

    public void setTotalCustomers(long totalCustomers) {
        this.totalCustomers = totalCustomers;
    }

    public long getActiveCustomers() {
        return activeCustomers;
    }

    public void setActiveCustomers(long activeCustomers) {
        this.activeCustomers = activeCustomers;
    }

    public long getUpcomingBookings() {
        return upcomingBookings;
    }

    public void setUpcomingBookings(long upcomingBookings) {
        this.upcomingBookings = upcomingBookings;
    }

    public long getUserTotalBookings() {
        return userTotalBookings;
    }

    public void setUserTotalBookings(long userTotalBookings) {
        this.userTotalBookings = userTotalBookings;
    }

    public long getUserActiveBookings() {
        return userActiveBookings;
    }

    public void setUserActiveBookings(long userActiveBookings) {
        this.userActiveBookings = userActiveBookings;
    }
}
