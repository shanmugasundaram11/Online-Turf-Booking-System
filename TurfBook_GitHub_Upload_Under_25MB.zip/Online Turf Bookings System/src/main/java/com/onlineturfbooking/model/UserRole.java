package com.onlineturfbooking.model;

public enum UserRole {
    CUSTOMER,
    ADMIN
}
