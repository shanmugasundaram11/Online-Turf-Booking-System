package com.onlineturfbooking.util;

import com.onlineturfbooking.model.User;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public final class SessionUtil {
    public static final String USER_ATTR = "currentUser";
    public static final String FLASH_SUCCESS = "flashSuccess";
    public static final String FLASH_ERROR = "flashError";

    private SessionUtil() {
    }

    public static void setUser(HttpSession session, User user) {
        session.setAttribute(USER_ATTR, user);
        CsrfUtil.ensureToken(session);
    }

    public static User getUser(HttpSession session) {
        if (session == null) {
            return null;
        }
        Object obj = session.getAttribute(USER_ATTR);
        return obj instanceof User ? (User) obj : null;
    }

    public static User getUser(HttpServletRequest request) {
        return getUser(request.getSession(false));
    }

    public static boolean isLoggedIn(HttpServletRequest request) {
        return getUser(request) != null;
    }

    public static void logout(HttpSession session) {
        if (session != null) {
            session.invalidate();
        }
    }

    public static void setFlashSuccess(HttpServletRequest request, String message) {
        HttpSession session = request.getSession(true);
        session.setAttribute(FLASH_SUCCESS, message);
    }

    public static void setFlashError(HttpServletRequest request, String message) {
        HttpSession session = request.getSession(true);
        session.setAttribute(FLASH_ERROR, message);
    }

    public static void exposeFlash(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return;
        }
        Object success = session.getAttribute(FLASH_SUCCESS);
        Object error = session.getAttribute(FLASH_ERROR);
        if (success != null) {
            request.setAttribute(FLASH_SUCCESS, success);
            session.removeAttribute(FLASH_SUCCESS);
        }
        if (error != null) {
            request.setAttribute(FLASH_ERROR, error);
            session.removeAttribute(FLASH_ERROR);
        }
    }
}
