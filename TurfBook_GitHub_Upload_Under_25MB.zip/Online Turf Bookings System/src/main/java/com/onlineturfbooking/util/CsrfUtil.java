package com.onlineturfbooking.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.security.SecureRandom;
import java.util.Base64;

public final class CsrfUtil {
    public static final String CSRF_TOKEN_ATTR = "csrfToken";
    public static final String CSRF_PARAM = "_csrf";

    private static final SecureRandom RANDOM = new SecureRandom();

    private CsrfUtil() {
    }

    public static String ensureToken(HttpSession session) {
        if (session == null) {
            return null;
        }
        String token = (String) session.getAttribute(CSRF_TOKEN_ATTR);
        if (token == null) {
            token = generateToken();
            session.setAttribute(CSRF_TOKEN_ATTR, token);
        }
        return token;
    }

    public static String generateToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    public static boolean isValid(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return false;
        }
        String sessionToken = (String) session.getAttribute(CSRF_TOKEN_ATTR);
        if (sessionToken == null) {
            return false;
        }
        String requestToken = request.getParameter(CSRF_PARAM);
        if (requestToken == null) {
            requestToken = request.getHeader("X-CSRF-TOKEN");
        }
        // For multipart/form-data requests the servlet container only makes
        // parameters available via getPart() -- getParameter() returns null in
        // a Filter context. Try to read the CSRF token from a part if needed.
        if (requestToken == null) {
            requestToken = readPartAsString(request, CSRF_PARAM);
        }
        return sessionToken.equals(requestToken);
    }

    /**
     * Reads a small text part from a multipart/form-data request.
     * Returns null on any error or if the request is not multipart.
     */
    private static String readPartAsString(HttpServletRequest request, String partName) {
        String ct = request.getContentType();
        if (ct == null || !ct.toLowerCase().contains("multipart/form-data")) {
            return null;
        }
        try {
            jakarta.servlet.http.Part part = request.getPart(partName);
            if (part == null) {
                return null;
            }
            try (java.io.InputStream is = part.getInputStream()) {
                return new String(is.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).trim();
            }
        } catch (Exception e) {
            return null;
        }
    }
}
