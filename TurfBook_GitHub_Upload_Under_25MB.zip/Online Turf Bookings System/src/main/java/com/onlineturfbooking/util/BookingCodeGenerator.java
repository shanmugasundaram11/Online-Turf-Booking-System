package com.onlineturfbooking.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

public final class BookingCodeGenerator {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyMMddHHmmss");

    private BookingCodeGenerator() {
    }

    public static String generate() {
        int suffix = ThreadLocalRandom.current().nextInt(100, 999);
        return "TB" + LocalDateTime.now().format(FMT) + suffix;
    }
}
