package com.onlineturfbooking.util;

/**
 * One-off helper to generate BCrypt hashes for sample-data.sql.
 * Run: mvn -q exec:java -Dexec.mainClass="com.onlineturfbooking.util.HashGenerator"
 */
public final class HashGenerator {
    private HashGenerator() {
    }

    public static void main(String[] args) {
        System.out.println("Admin@123 = " + PasswordUtil.hash("Admin@123"));
        System.out.println("Customer@123 = " + PasswordUtil.hash("Customer@123"));
    }
}
