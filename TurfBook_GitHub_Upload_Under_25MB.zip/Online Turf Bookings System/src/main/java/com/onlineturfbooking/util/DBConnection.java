package com.onlineturfbooking.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manages JDBC connections using classpath db.properties.
 */
public final class DBConnection {
    private static final Logger LOGGER = Logger.getLogger(DBConnection.class.getName());
    private static final Properties PROPS = new Properties();
    private static boolean initialized = false;

    static {
        loadProperties();
    }

    private DBConnection() {
    }

    private static void loadProperties() {
        try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in == null) {
                LOGGER.severe("db.properties not found on classpath. Copy db.properties.example to db.properties.");
                return;
            }
            PROPS.load(in);
            String driver = PROPS.getProperty("db.driver", "com.mysql.cj.jdbc.Driver");
            Class.forName(driver);
            initialized = true;
            LOGGER.info("Database configuration loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            LOGGER.log(Level.SEVERE, "Failed to initialize database configuration", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        if (!initialized) {
            throw new SQLException("Database configuration is not initialized. Check db.properties.");
        }
        String url = PROPS.getProperty("db.url");
        String username = PROPS.getProperty("db.username");
        String password = PROPS.getProperty("db.password");
        Connection conn = DriverManager.getConnection(url, username, password);
        conn.setAutoCommit(true);
        return conn;
    }

    public static boolean isConfigured() {
        return initialized;
    }
}
