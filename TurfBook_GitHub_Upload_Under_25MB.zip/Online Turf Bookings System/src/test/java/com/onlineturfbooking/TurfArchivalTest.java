package com.onlineturfbooking;

import com.onlineturfbooking.dao.TurfDao;
import com.onlineturfbooking.exception.AppException;
import com.onlineturfbooking.model.Booking;
import com.onlineturfbooking.model.BookingStatus;
import com.onlineturfbooking.model.Turf;
import com.onlineturfbooking.model.TurfStatus;
import com.onlineturfbooking.service.TurfService;
import com.onlineturfbooking.util.DBConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

/**
 * Verification test suite for:
 * Task: Improve Admin Delete Turf Logic — Preserve Booking History
 */
public class TurfArchivalTest {

    private static int testsPassed = 0;
    private static int testsFailed = 0;

    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("Running Turf Archival & Booking History Test Suite");
        System.out.println("==================================================");

        testEnumAndModel();
        testTimeComparisonLogic();
        testDatabaseAndServiceIntegrity();

        System.out.println("==================================================");
        System.out.println("Test Results: " + testsPassed + " passed, " + testsFailed + " failed.");
        System.out.println("==================================================");
        if (testsFailed > 0) {
            System.exit(1);
        }
    }

    private static void assertTrue(String name, boolean condition) {
        if (condition) {
            System.out.println("[PASS] " + name);
            testsPassed++;
        } else {
            System.err.println("[FAIL] " + name);
            testsFailed++;
        }
    }

    private static void assertEquals(String name, Object expected, Object actual) {
        if (expected == null && actual == null || (expected != null && expected.equals(actual))) {
            System.out.println("[PASS] " + name);
            testsPassed++;
        } else {
            System.err.println("[FAIL] " + name + " (Expected: " + expected + ", Actual: " + actual + ")");
            testsFailed++;
        }
    }

    private static void testEnumAndModel() {
        System.out.println("\n--- 1. Enum & Model Status Tests ---");
        try {
            TurfStatus status = TurfStatus.valueOf("ARCHIVED");
            assertEquals("TurfStatus has ARCHIVED value", TurfStatus.ARCHIVED, status);

            Turf turf = new Turf();
            turf.setStatus(TurfStatus.ARCHIVED);
            assertTrue("Archived turf is not active", !turf.isActive());
            assertTrue("Archived turf isArchived is true", turf.isArchived());

            turf.setStatus(TurfStatus.ACTIVE);
            assertTrue("Active turf isActive is true", turf.isActive());
            assertTrue("Active turf isArchived is false", !turf.isArchived());

            turf.setStatus(TurfStatus.INACTIVE);
            assertTrue("Inactive turf isActive is false", !turf.isActive());
            assertTrue("Inactive turf isArchived is false", !turf.isArchived());
        } catch (Exception e) {
            assertTrue("Enum test threw exception: " + e.getMessage(), false);
        }
    }

    private static void testTimeComparisonLogic() {
        System.out.println("\n--- 2. Booking Completion & Time Logic Tests ---");
        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now();

        // Case A: Future date -> must be upcoming
        LocalDate tomorrow = today.plusDays(1);
        boolean tomorrowIsUpcoming = tomorrow.isAfter(today) || (tomorrow.equals(today) && now.isBefore(LocalTime.of(23, 0)));
        assertTrue("Future date booking is upcoming", tomorrowIsUpcoming);

        // Case B: Past date -> not upcoming/in-progress
        LocalDate yesterday = today.minusDays(1);
        boolean yesterdayIsUpcoming = yesterday.isAfter(today) || (yesterday.equals(today) && now.isBefore(LocalTime.of(23, 0)));
        assertTrue("Past date booking is not upcoming", !yesterdayIsUpcoming);

        // Case C: Today, start time passed, but end time in future -> IN PROGRESS
        LocalTime pastStart = now.minusHours(1);
        LocalTime futureEnd = now.plusHours(1);
        boolean isInProgress = (pastStart.isBefore(now) && futureEnd.isAfter(now));
        assertTrue("Booking currently in progress (start passed, end not passed) is detected", isInProgress);

        // Case D: Today, end time passed -> finished
        LocalTime pastEnd = now.minusMinutes(10);
        boolean isFinished = pastEnd.isBefore(now);
        assertTrue("Booking with end time in the past is finished", isFinished);
    }

    private static void testDatabaseAndServiceIntegrity() {
        System.out.println("\n--- 3. Database & Service Flow Tests ---");
        TurfService service = new TurfService();
        TurfDao dao = new TurfDao();

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            System.out.println("[INFO] Connected to MySQL successfully.");
        } catch (SQLException e) {
            System.out.println("[WARN] Could not connect to MySQL (" + e.getMessage() + "). Skipping live DB execution.");
            return;
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException ignored) {}
            }
        }

        // Apply migration if needed (non-destructive ALTER TABLE)
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement()) {
            st.executeUpdate("ALTER TABLE turfs MODIFY COLUMN status ENUM('ACTIVE', 'INACTIVE', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE'");
            System.out.println("[INFO] Verified/Applied schema migration for ARCHIVED status enum.");
        } catch (SQLException e) {
            System.err.println("[WARN] Could not execute schema modification: " + e.getMessage());
        }

        long tempTurfId = 0;
        long tempBookingId = 0;
        try {
            // Test 1: Create a temporary test turf
            tempTurfId = dao.create(buildTempTurf("Test Archival Turf 999", TurfStatus.ACTIVE));
            assertTrue("Created temp turf with ID=" + tempTurfId, tempTurfId > 0);

            // Test 2: Turf has 0 bookings -> should PERMANENTLY delete
            TurfService.DeleteTurfResult delResult = service.deleteTurf(tempTurfId);
            assertEquals("Turf with 0 bookings is permanently deleted",
                    TurfService.DeleteOutcome.PERMANENTLY_DELETED, delResult.getOutcome());
            assertTrue("Turf row no longer exists in DB", dao.findById(tempTurfId).isEmpty());

            // Test 3: Create turf with past/completed booking -> should ARCHIVE, not delete
            tempTurfId = dao.create(buildTempTurf("Test History Turf 888", TurfStatus.ACTIVE));
            tempBookingId = createHistoricalBooking(tempTurfId, BookingStatus.COMPLETED, LocalDate.now().minusDays(2));
            assertTrue("Created historical completed booking with ID=" + tempBookingId, tempBookingId > 0);

            TurfService.DeleteTurfResult archResult = service.deleteTurf(tempTurfId);
            assertEquals("Turf with completed booking history is ARCHIVED",
                    TurfService.DeleteOutcome.ARCHIVED, archResult.getOutcome());
            Optional<Turf> archivedTurf = dao.findById(tempTurfId);
            assertTrue("Archived turf still exists in DB", archivedTurf.isPresent());
            assertEquals("Archived turf status in DB is ARCHIVED", TurfStatus.ARCHIVED, archivedTurf.get().getStatus());

            // Test 4: Cannot edit an archived turf directly
            try {
                service.updateTurf(tempTurfId, "Modified Name", "Loc", "Desc with enough text here",
                        "1000", "06:00", "22:00", "Amenities", null, "#1a5c3a", TurfStatus.ACTIVE);
                assertTrue("Editing archived turf directly should be blocked", false);
            } catch (AppException e) {
                assertTrue("Editing archived turf blocked: " + e.getMessage(), true);
            }

            // Test 5: Cannot toggle status of archived turf directly
            try {
                service.setStatus(tempTurfId, TurfStatus.ACTIVE);
                assertTrue("Directly activating archived turf should be blocked", false);
            } catch (AppException e) {
                assertTrue("Activating archived turf blocked: " + e.getMessage(), true);
            }

            // Test 6: Safe restoration sets status to INACTIVE
            service.restoreTurf(tempTurfId);
            Optional<Turf> restoredTurf = dao.findById(tempTurfId);
            assertTrue("Restored turf exists", restoredTurf.isPresent());
            assertEquals("Restored turf has INACTIVE status", TurfStatus.INACTIVE, restoredTurf.get().getStatus());

            // Test 7: Block deletion/archiving if there is an active/upcoming confirmed booking
            // Set turf to ACTIVE, add a future confirmed booking
            service.setStatus(tempTurfId, TurfStatus.ACTIVE);
            long futureBookingId = createHistoricalBooking(tempTurfId, BookingStatus.CONFIRMED, LocalDate.now().plusDays(2));
            try {
                service.deleteTurf(tempTurfId);
                assertTrue("Deleting turf with future confirmed booking should be blocked", false);
            } catch (AppException e) {
                assertTrue("Deleting turf with future booking blocked with clear error: " + e.getMessage(),
                        e.getMessage().contains("active or upcoming confirmed bookings"));
            }

            // Test 8: Block deletion/archiving if booking is currently in progress
            // Cancel the future booking, create an in-progress booking (started earlier, ends later)
            cancelBooking(futureBookingId);
            long inProgressBookingId = createInProgressBooking(tempTurfId);
            try {
                service.deleteTurf(tempTurfId);
                assertTrue("Deleting turf with booking in progress should be blocked", false);
            } catch (AppException e) {
                assertTrue("Deleting turf with in-progress booking blocked: " + e.getMessage(),
                        e.getMessage().contains("active or upcoming confirmed bookings"));
            }

            // Cancel the in-progress booking
            cancelBooking(inProgressBookingId);

            // Now turf has only cancelled/completed bookings -> archiving should succeed!
            TurfService.DeleteTurfResult reArchiveResult = service.deleteTurf(tempTurfId);
            assertEquals("Turf with now-cancelled bookings is successfully ARCHIVED",
                    TurfService.DeleteOutcome.ARCHIVED, reArchiveResult.getOutcome());

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue("Test database flow failed: " + e.getMessage(), false);
        } finally {
            // Clean up temporary test data
            cleanUpTestData(tempTurfId);
        }
    }

    private static Turf buildTempTurf(String name, TurfStatus status) {
        Turf t = new Turf();
        t.setName(name);
        t.setLocation("Test City");
        t.setDescription("A test description long enough for validation rules");
        t.setPricePerHour(new BigDecimal("1000.00"));
        t.setOpeningTime(LocalTime.of(6, 0));
        t.setClosingTime(LocalTime.of(22, 0));
        t.setAmenities("Floodlights, Parking");
        t.setImageColor("#1a5c3a");
        t.setStatus(status);
        return t;
    }

    private static long createHistoricalBooking(long turfId, BookingStatus status, LocalDate date) throws SQLException {
        String sql = """
                INSERT INTO bookings (booking_code, customer_id, turf_id, booking_date, start_time, end_time,
                                     duration_hours, price_per_hour, total_amount, status)
                VALUES (?, 2, ?, ?, '10:00:00', '12:00:00', 2.0, 1000.00, 2000.00, ?)
                """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, "TESTBK" + System.currentTimeMillis() % 1000000);
            ps.setLong(2, turfId);
            ps.setDate(3, Date.valueOf(date));
            ps.setString(4, status.name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getLong(1);
                }
            }
        }
        return 0;
    }

    private static long createInProgressBooking(long turfId) throws SQLException {
        LocalTime now = LocalTime.now();
        LocalTime start = now.minusMinutes(30);
        LocalTime end = now.plusMinutes(90);
        String sql = """
                INSERT INTO bookings (booking_code, customer_id, turf_id, booking_date, start_time, end_time,
                                     duration_hours, price_per_hour, total_amount, status)
                VALUES (?, 2, ?, ?, ?, ?, 2.0, 1000.00, 2000.00, 'CONFIRMED')
                """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, "TESTINP" + System.currentTimeMillis() % 1000000);
            ps.setLong(2, turfId);
            ps.setDate(3, Date.valueOf(LocalDate.now()));
            ps.setTime(4, Time.valueOf(start));
            ps.setTime(5, Time.valueOf(end));
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getLong(1);
                }
            }
        }
        return 0;
    }

    private static void cancelBooking(long bookingId) {
        if (bookingId <= 0) return;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE bookings SET status = 'CANCELLED' WHERE id = ?")) {
            ps.setLong(1, bookingId);
            ps.executeUpdate();
        } catch (SQLException ignored) {}
    }

    private static void cleanUpTestData(long turfId) {
        if (turfId <= 0) return;
        try (Connection conn = DBConnection.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM booking_slots WHERE turf_id = ?")) {
                ps.setLong(1, turfId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM bookings WHERE turf_id = ?")) {
                ps.setLong(1, turfId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM turfs WHERE id = ?")) {
                ps.setLong(1, turfId);
                ps.executeUpdate();
            }
            System.out.println("[INFO] Cleaned up test records for turf ID=" + turfId);
        } catch (SQLException ignored) {}
    }
}
