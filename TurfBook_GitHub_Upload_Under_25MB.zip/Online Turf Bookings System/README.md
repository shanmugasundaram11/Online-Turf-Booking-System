# Online Turf Booking System

A polished, resume-ready **Online Turf Booking System** built as a traditional Java web application (Jakarta Servlets + JSP + JDBC + MySQL). Customers can browse turfs, select consecutive hourly slots, and book with conflict-free availability. Admins manage turfs, bookings, and customers from a dedicated portal.

## Features

### Customer
- Landing page, turf browse, and turf details
- Registration / login with BCrypt password hashing
- Date-based availability and multi-hour consecutive slot booking
- Atomic bookings that lock every covered hour
- Dashboard, profile, booking history, and cancellation (2+ hours before start)

### Admin
- Separate admin login UI
- Dashboard statistics from live database data
- Turf CRUD, activate/deactivate, pricing and hours
- Booking search/filter and status updates
- Customer search and activate/deactivate

### Security
- Session authentication and role-based authorization
- PreparedStatements (SQL injection resistant)
- CSRF tokens on state-changing requests
- Session regeneration after login
- Input validation and escaped JSP output (JSTL/EL)

## Technology Stack

| Layer | Technology |
|-------|------------|
| Language | Java 17 |
| Web | Jakarta Servlets, JSP, JSTL |
| Data | JDBC, MySQL 8+ |
| Build | Maven (WAR) |
| Server | Apache Tomcat 10.1+ |
| Auth | Session + BCrypt |

## Architecture

```
Servlet (Controller)
    → Service (Business logic)
        → DAO (JDBC / PreparedStatements)
            → MySQL
Model + Filter + Utility layers support MVC separation.
```

Package root: `com.onlineturfbooking`

## Project Structure

```
database/
  schema.sql
  sample-data.sql
src/main/java/com/onlineturfbooking/
  model/
  dao/
  service/
  servlet/          (public, customer, admin)
  filter/
  util/
  exception/
src/main/resources/
  db.properties.example
  db.properties          (local; create from example)
src/main/webapp/
  css/ js/
  WEB-INF/web.xml
  WEB-INF/views/         (public, auth, customer, admin, error)
```

## Database Setup

1. Install MySQL 8+ and start the service.
2. Create schema + sample data (Windows helper):

```bat
setup-database.bat YOUR_MYSQL_ROOT_PASSWORD
```

Or manually:

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/sample-data.sql
```

3. Copy configuration (if needed):

```bat
copy src\main\resources\db.properties.example src\main\resources\db.properties
```

4. Edit `src/main/resources/db.properties` with your MySQL username/password, then rebuild.

Database name: `online_turf_booking`

## Build

```bash
mvn clean package
```

Produces: `target/online-turf-booking.war`

## Deploy to Tomcat 10.1+

1. Ensure Tomcat 10.1+ is installed (Jakarta EE / `jakarta.*` namespace).
2. Copy `target/online-turf-booking.war` into Tomcat `webapps/`.
3. Start Tomcat.
4. Open: `http://localhost:8080/online-turf-booking/`

### IDE option (IntelliJ / Eclipse)
- Import as Maven project
- Add Tomcat 10.1+ run configuration
- Deploy the WAR / exploded artifact
- Set JVM to Java 17+

## Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@turfbook.com` | `Admin@123` |
| Customer | `rahul@example.com` | `Customer@123` |
| Customer | `priya@example.com` | `Customer@123` |
| Customer | `arjun@example.com` | `Customer@123` |

Admin portal: `/admin/login`  
Customer login: `/login`

## Main User Flows

1. **Book a turf:** Home → Browse Turfs → Turf Details → pick date → select consecutive hours → confirm → My Bookings  
2. **Cancel:** My Bookings → Details → Cancel (only if ≥ 2 hours before start)  
3. **Admin:** Admin login → Dashboard → manage turfs / bookings / customers  

## Booking Integrity

- Booking `09:00–11:00` reserves hours `09` and `10` in `booking_slots`
- Unique constraint on `(turf_id, slot_date, slot_hour)` prevents double booking
- Creates booking + slots inside a single DB transaction
- Cancellation deletes slot rows so hours become available again

## Security Features

- BCrypt password hashes (never plain text)
- CSRF protection on POST
- Role checks (customers cannot open admin pages)
- Auth filters for protected routes
- Friendly error pages (404 / 403 / 500)

## Future Improvements

- Online payments (UPI / Razorpay)
- Email / SMS booking notifications
- Turf image upload
- Recurring bookings and waitlists
- Connection pooling (HikariCP)

## Interview Talking Points

- MVC with Servlet → Service → DAO
- JDBC transactions and conflict handling for overlapping bookings
- Session auth, authorization filters, CSRF, BCrypt
- Responsive vanilla JS UI without SPA frameworks
